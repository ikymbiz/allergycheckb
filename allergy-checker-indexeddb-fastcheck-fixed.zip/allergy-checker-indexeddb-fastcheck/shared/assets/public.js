const I18N = {
  ja: {
    scan: '🔍 スキャン開始', capture: '📸 判定する', light: '🔦 LIGHT', photo: '📁 PHOTO',
    hold: '動かさないでください...', loading: 'AI分析中...', apiMissing: '管理アプリでGemini API Keyを設定してください。',
    safe: 'OCR上は未検出', critical: '避けたい成分を検出', warning: '注意が必要です', unknown: '判定できません',
    disclaimer: 'この判定は参考情報です。購入・飲食前に必ず商品の原材料表示、アレルギー表示、メーカー公式情報を確認してください。',
    product: '商品名', category: 'カテゴリ', detected: '検出された成分', warnings: '注意表記', ingredients: 'Ingredients List', ocr: 'OCR全文', raw: 'Raw JSON',
    noMatches: '該当なし', recommendations: '代替商品リスト', amazon: 'Amazon検索結果', rakuten: '楽天検索結果', custom: 'リンクを開く',
    productCandidates: '具体的な商品候補', reason: '理由', allergenNote: 'アレルゲン', caution: '注意', photoUnavailable: '商品写真未取得', imageSearch: '画像検索で確認', searchKeyword: '検索キーワード', photoSourceRakuten: '楽天検索結果から取得', photoSourceSearch: '画像検索サムネイル' 
  },
  en: {
    scan: '🔍 START SCAN', capture: '📸 CAPTURE', light: '🔦 LIGHT', photo: '📁 PHOTO',
    hold: 'Hold steady...', loading: 'Analyzing...', apiMissing: 'Set Gemini API Key in the admin app first.',
    safe: 'Not detected in OCR', critical: 'Restricted ingredient detected', warning: 'Caution required', unknown: 'Unable to determine',
    disclaimer: 'This result is for reference only. Always check the product label, allergy information, and official manufacturer information before purchase or consumption.',
    product: 'Product', category: 'Category', detected: 'Detected ingredients', warnings: 'Warnings', ingredients: 'Ingredients List', ocr: 'Full OCR Text', raw: 'Raw JSON',
    noMatches: 'None', recommendations: 'Alternative Product List', amazon: 'Amazon Search Results', rakuten: 'Rakuten Search Results', custom: 'Open Link',
    productCandidates: 'Specific Product Candidates', reason: 'Reason', allergenNote: 'Allergen note', caution: 'Caution', photoUnavailable: 'Product photo unavailable', imageSearch: 'Check with image search', searchKeyword: 'Search keyword', photoSourceRakuten: 'Fetched from Rakuten search results', photoSourceSearch: 'Image search thumbnail' 
  }
};

const COMMON_ALLERGENS_JA = ['小麦','乳','卵','えび','かに','そば','落花生','ピーナッツ','くるみ','カシューナッツ','大豆','ごま','アーモンド','オレンジ','キウイ','牛肉','鶏肉','豚肉','さけ','さば','いか','いくら','バナナ','もも','やまいも','りんご','ゼラチン','グルテン','ナッツ','Vegan'];
const COMMON_ALLERGENS_EN = ['wheat','milk','egg','shrimp','crab','buckwheat','peanut','walnut','cashew','soy','sesame','almond','orange','kiwi','beef','chicken','pork','salmon','mackerel','squid','banana','peach','apple','gelatin','gluten','nuts','vegan'];

let cameraStream = null;
let currentConfig = null;

function userLang() { return localStorage.getItem('ui_lang') || 'ja'; }
function t() { return I18N[userLang()] || I18N.ja; }
function userAllergens() { return toArray(localStorage.getItem('my_diet') || ''); }

async function initPublicApp() {
  await seedInitialDataIfNeeded();
  currentConfig = await getConfig();
  applySiteChrome(currentConfig);
  const scanBtn = document.getElementById('ui-scan-btn');
  if (scanBtn) scanBtn.textContent = t().scan;
  const torchBtn = document.getElementById('ui-torch-btn');
  if (torchBtn) torchBtn.textContent = t().light;
  const photoBtn = document.getElementById('ui-photo-btn');
  if (photoBtn) photoBtn.textContent = t().photo;
  const footer = document.getElementById('safety-disclaimer');
  if (footer) footer.textContent = currentConfig.safetyDisclaimer || t().disclaimer;
  renderAdPlaceholder('main');
}

function applySiteChrome(config) {
  document.querySelectorAll('[data-site-name]').forEach(el => el.textContent = config.siteName || 'Allergy Checker AI');
  document.title = config.siteName || document.title;
}

async function handleScanButton() {
  if (!cameraStream) {
    try {
      cameraStream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment', width: { ideal: 1920 }, height: { ideal: 1080 } }, audio: false });
      document.getElementById('video').srcObject = cameraStream;
      document.getElementById('video').style.display = 'block';
      document.getElementById('file-preview').style.display = 'none';
      document.getElementById('empty-preview').style.display = 'none';
      document.getElementById('scan-line').style.display = 'block';
      document.getElementById('ui-scan-btn').textContent = t().capture;
      clearPreviewResultOverlay();
    } catch (err) {
      alert('Camera Error: ' + err.message);
    }
  } else {
    capture();
  }
}

async function capture() {
  showLoading(t().hold);
  const video = document.getElementById('video');
  const canvas = document.createElement('canvas');
  const MAX_W = 1600;
  let w = video.videoWidth;
  let h = video.videoHeight;
  if (!w || !h) { hideLoading(); alert('Camera Error'); return; }
  if (w > MAX_W) { h *= MAX_W / w; w = MAX_W; }
  canvas.width = Math.round(w);
  canvas.height = Math.round(h);
  canvas.getContext('2d').drawImage(video, 0, 0, canvas.width, canvas.height);
  const dataUrl = canvas.toDataURL('image/jpeg', 0.86);
  const base64 = dataUrl.split(',')[1];
  const preview = document.getElementById('file-preview');
  preview.src = dataUrl;
  preview.style.display = 'block';
  document.getElementById('empty-preview').style.display = 'none';
  stopCamera();
  analyze(base64, 'image/jpeg');
}

function stopCamera() {
  if (cameraStream) {
    cameraStream.getTracks().forEach(track => track.stop());
    cameraStream = null;
  }
  const video = document.getElementById('video');
  if (video) video.style.display = 'none';
  const scanLine = document.getElementById('scan-line');
  if (scanLine) scanLine.style.display = 'none';
  const scanBtn = document.getElementById('ui-scan-btn');
  if (scanBtn) scanBtn.textContent = t().scan;
}

async function toggleTorch() {
  if (!cameraStream) return;
  const track = cameraStream.getVideoTracks()[0];
  const capabilities = track.getCapabilities ? track.getCapabilities() : {};
  const settings = track.getSettings ? track.getSettings() : {};
  if (capabilities.torch) await track.applyConstraints({ advanced: [{ torch: !settings.torch }] });
}

function handleFileSelect(event) {
  const file = event.target.files && event.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = async e => {
    const dataUrl = e.target.result;
    clearPreviewResultOverlay();
    document.getElementById('file-preview').src = dataUrl;
    document.getElementById('file-preview').style.display = 'block';
    document.getElementById('empty-preview').style.display = 'none';
    stopCamera();
    const resized = await resizeImageDataUrl(dataUrl, 1600, 0.86);
    analyze(resized.dataUrl.split(',')[1], resized.mimeType);
  };
  reader.readAsDataURL(file);
}

async function analyze(base64, mimeType) {
  showLoading(t().loading);
  try {
    currentConfig = await getConfig();
    let result;
    if (currentConfig.requestMode === 'mock') {
      result = await analyzeMock();
    } else {
      result = await analyzeGeminiDirect(base64, mimeType, currentConfig);
    }
    result = normalizeAnalysisResult(result);
    result = applyLocalAllergenJudgement(result);
    result = await enrichRecommendationItemsWithRakuten(result, currentConfig);
    renderResult(result);
    const keywords = uniqueArray([...(result.recommendation_queries || []), ...(result.recommendation_items || []).map(item => item.search_query || item.name).filter(Boolean)]);
    for (const q of keywords) {
      await logSearchEvent({ keyword: q, category: result.category, allergens: userAllergens(), source: 'scan' });
    }
  } catch (err) {
    console.error(err);
    alert((err && err.message) || String(err));
  } finally {
    hideLoading();
  }
}

async function analyzeGeminiDirect(base64, mimeType, config) {
  if (!config.geminiApiKey) throw new Error(t().apiMissing);
  const model = config.geminiModel || 'gemini-2.0-flash';
  const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(config.geminiApiKey)}`;
  const systemPrompt = userLang() === 'ja' ? config.systemPromptJa : config.systemPromptEn;
  const body = {
    systemInstruction: { parts: [{ text: systemPrompt }] },
    contents: [{ role: 'user', parts: [{ text: buildUserPrompt() }, { inlineData: { mimeType, data: base64 } }] }],
    generationConfig: { temperature: 0.1, topP: 0.8, topK: 40, responseMimeType: 'application/json' }
  };
  const res = await fetch(endpoint, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
  const json = await res.json();
  if (!res.ok) throw new Error(json?.error?.message || `Gemini API error: ${res.status}`);
  const text = json?.candidates?.[0]?.content?.parts?.map(p => p.text || '').join('\n').trim();
  return parseJsonFromModelText(text);
}

function buildUserPrompt() {
  return `ユーザー言語: ${userLang() === 'ja' ? 'Japanese' : 'English'}\nユーザーが避けたい成分・アレルゲン・食事制限: ${userAllergens().join(', ') || '未設定'}\n\nこの画像の食品表示を読み取り、system promptのJSONスキーマに厳密に従ってJSONのみを返してください。\n安全だと断定せず、OCR結果から判断できる範囲だけを返してください。\n代替商品は具体的な商品名、検索結果リンク用の検索キーワード、商品写真表示用のimage_queryを含むrecommendation_itemsとして返してください。\nAmazonや楽天の個別商品URLは返さず、検索結果に使えるsearch_queryを返してください。`;
}

async function analyzeMock() {
  await new Promise(resolve => setTimeout(resolve, 700));
  const restricted = userAllergens();
  const restrictedText = restricted.join(', ');
  const hasGelatinApple = /ゼラチン|りんご|gelatin|apple/i.test(restrictedText);
  if (hasGelatinApple || userLang() === 'ja') {
    return {
      status: 'danger',
      product_name: userLang() === 'ja' ? 'サンプル グミ' : 'Sample Gummy Candy',
      category: userLang() === 'ja' ? 'グミ・キャンディ' : 'Gummy / Candy',
      ocr_text: userLang() === 'ja' ? '名称: グミキャンディ\n原材料名: 水あめ、砂糖、ゼラチン、濃縮りんご果汁、酸味料、香料\n一部にりんご・ゼラチンを含む' : 'Name: Gummy candy\nIngredients: starch syrup, sugar, gelatin, concentrated apple juice, acidulant, flavoring. Contains apple and gelatin.',
      ingredients: userLang() === 'ja' ? '水あめ、砂糖、ゼラチン、濃縮りんご果汁、酸味料、香料' : 'starch syrup, sugar, gelatin, concentrated apple juice, acidulant, flavoring',
      allergy_label: userLang() === 'ja' ? '一部にりんご・ゼラチンを含む' : 'Contains apple and gelatin',
      translated_ingredients: userLang() === 'ja' ? '水あめ、砂糖、ゼラチン、濃縮りんご果汁、酸味料、香料' : 'Starch syrup, sugar, gelatin, concentrated apple juice, acidulant, flavoring',
      detected_allergens: userLang() === 'ja' ? ['ゼラチン', 'りんご'] : ['gelatin', 'apple'],
      matches: userLang() === 'ja' ? ['ゼラチン', 'りんご'] : ['gelatin', 'apple'],
      may_contain: [],
      recommendation_queries: userLang() === 'ja' ? ['ボンタンアメ', '兵六餅', 'ビオクラ 有機グミ コーラ', '杉本屋 厚切り寒天'] : ['Bontan Ame', 'Hyoroku Mochi', 'Biokura Organic Gummy Cola', 'Sugimotoya Thick-Cut Kanten'],
      recommendation_items: userLang() === 'ja' ? [
        { rank: 1, name: 'セイカ食品 ボンタンアメ', search_query: 'ボンタンアメ', image_query: 'セイカ食品 ボンタンアメ', image_url: '', reason: 'もち米を主原料としたもちもちした菓子で、グミの代替として探しやすい候補です。', allergen_note: 'ゼラチン・りんご不使用の候補として確認対象です。大豆など他アレルゲンは要確認です。', caution: '購入前に最新の原材料表示とメーカー公式情報を確認してください。' },
        { rank: 2, name: 'セイカ食品 兵六餅', search_query: '兵六餅', image_query: 'セイカ食品 兵六餅', image_url: '', reason: 'ボンタンアメの姉妹品で、もちもちした食感の代替候補です。', allergen_note: 'ゼラチン・りんご不使用の候補として確認対象です。大豆など他アレルゲンは要確認です。', caution: '海苔や抹茶風味があるため、原材料とアレルギー表示を確認してください。' },
        { rank: 3, name: 'ビオクラ 有機グミ コーラ味', search_query: 'ビオクラ 有機グミ コーラ', image_query: 'ビオクラ 有機グミ コーラ味', image_url: '', reason: 'ゼラチンの代わりに植物由来原料を使うヴィーガングミ系の候補です。', allergen_note: 'フルーツ味はりんごを含む可能性があるため、コーラ味を優先して確認してください。', caution: '味違いで原材料が変わるため、必ずコーラ味の表示を確認してください。' },
        { rank: 4, name: '杉本屋製菓 厚切り寒天', search_query: '杉本屋 厚切り寒天', image_query: '杉本屋製菓 厚切り寒天', image_url: '', reason: 'ゼラチンではなく寒天を使った菓子で、ゼリーとグミの中間の食感の候補です。', allergen_note: 'ミックス味は避け、ぶどう味やコーラ味などを選んで原材料を確認してください。', caution: '味によって果汁や香料が異なるため、りんご由来成分がないか確認してください。' }
      ] : [
        { rank: 1, name: 'Seika Foods Bontan Ame', search_query: 'Bontan Ame', image_query: 'Seika Foods Bontan Ame', image_url: '', reason: 'A chewy rice-based candy candidate that can be searched as an alternative to gummies.', allergen_note: 'Candidate to check for gelatin-free and apple-free needs. Verify soy and other allergens.', caution: 'Always verify the latest ingredient label and official manufacturer information.' },
        { rank: 2, name: 'Seika Foods Hyoroku Mochi', search_query: 'Hyoroku Mochi', image_query: 'Seika Foods Hyoroku Mochi', image_url: '', reason: 'A related chewy candy candidate.', allergen_note: 'Candidate to check for gelatin-free and apple-free needs.', caution: 'Check ingredients and allergy label before purchase.' },
        { rank: 3, name: 'Biokura Organic Gummy Cola Flavor', search_query: 'Biokura Organic Gummy Cola', image_query: 'Biokura Organic Gummy Cola Flavor', image_url: '', reason: 'A vegan-style gummy candidate using plant-derived gelling agents.', allergen_note: 'Fruit flavors may contain apple, so prioritize cola flavor and verify.', caution: 'Ingredients differ by flavor. Verify cola flavor specifically.' },
        { rank: 4, name: 'Sugimotoya Thick-Cut Kanten', search_query: 'Sugimotoya Thick-Cut Kanten', image_query: 'Sugimotoya Thick-Cut Kanten', image_url: '', reason: 'A kanten-based snack candidate with jelly-like texture.', allergen_note: 'Choose non-mixed flavors and verify no apple-derived ingredients.', caution: 'Ingredients vary by flavor. Check label before purchase.' }
      ],
      suitability_note: userLang() === 'ja' ? 'OCR結果ではゼラチンとりんごが検出されました。代替候補は検索用の参考情報です。購入・飲食前に必ず表示を確認してください。' : 'The OCR result detected gelatin and apple. Alternative candidates are reference search suggestions only. Always verify labels before purchase or consumption.',
      confidence: 'high',
      notes: userLang() === 'ja' ? ['検索結果リンクは個別商品の安全性を保証しません。', '写真は設定された楽天APIまたは返却されたimage_urlから表示します。'] : ['Search result links do not guarantee product safety.', 'Photos are displayed from configured Rakuten API or returned image_url.']
    };
  }

  const hasWheat = restricted.some(v => /小麦|wheat|gluten/i.test(v));
  return {
    status: hasWheat ? 'danger' : 'warning',
    product_name: userLang() === 'ja' ? 'サンプル クッキー' : 'Sample Cookies',
    category: userLang() === 'ja' ? 'クッキー' : 'Cookies',
    ocr_text: userLang() === 'ja' ? '名称: クッキー\n原材料名: 小麦粉、砂糖、植物油脂、卵、食塩 / 膨張剤、香料\n一部に小麦・卵を含む\n本品製造工場では乳成分を含む製品を製造しています。' : 'Name: Cookies\nIngredients: wheat flour, sugar, vegetable oil, egg, salt, baking powder, flavoring. Contains wheat and egg. Manufactured in a facility that also processes milk.',
    ingredients: userLang() === 'ja' ? '小麦粉、砂糖、植物油脂、卵、食塩 / 膨張剤、香料' : 'wheat flour, sugar, vegetable oil, egg, salt, baking powder, flavoring',
    allergy_label: userLang() === 'ja' ? '一部に小麦・卵を含む。本品製造工場では乳成分を含む製品を製造しています。' : 'Contains wheat and egg. Manufactured in a facility that also processes milk.',
    translated_ingredients: userLang() === 'ja' ? '小麦粉、砂糖、植物油脂、卵、食塩、膨張剤、香料' : 'Wheat flour, sugar, vegetable oil, egg, salt, baking powder, flavoring',
    detected_allergens: userLang() === 'ja' ? ['小麦', '卵', '乳成分の製造ライン注意'] : ['wheat', 'egg', 'milk facility warning'],
    matches: hasWheat ? (userLang() === 'ja' ? ['小麦'] : ['wheat']) : [],
    may_contain: userLang() === 'ja' ? ['乳成分を含む製品を同じ工場で製造'] : ['Manufactured in a facility that also processes milk'],
    recommendation_queries: userLang() === 'ja' ? ['小麦不使用 クッキー', 'グルテンフリー クッキー', '米粉 クッキー アレルギー対応'] : ['wheat free cookies', 'gluten free cookies', 'allergy friendly rice flour cookies'],
    recommendation_items: [],
    suitability_note: userLang() === 'ja' ? 'OCR結果では小麦と卵が検出され、乳成分に関する製造ライン注意もあります。購入・飲食前に必ず表示を確認してください。' : 'The OCR result detected wheat and egg, with a milk facility warning. Always verify the product label before purchase or consumption.',
    confidence: 'high', notes: []
  };
}

function normalizeAnalysisResult(data) {
  const raw = data && typeof data === 'object' ? data : {};
  let status = raw.status || 'unknown';
  if (status === 'safe') status = 'clear';
  if (!['danger', 'warning', 'clear', 'unknown'].includes(status)) status = 'unknown';
  return {
    status,
    product_name: raw.product_name || raw.productName || '不明',
    category: raw.category || '不明',
    ocr_text: raw.ocr_text || raw.ocrText || '',
    ingredients: raw.ingredients || '',
    allergy_label: raw.allergy_label || raw.allergyLabel || '',
    translated_ingredients: raw.translated_ingredients || raw.translatedIngredients || raw.ingredients || '',
    detected_allergens: toArray(raw.detected_allergens || raw.detectedAllergens),
    matches: toArray(raw.matches),
    may_contain: toArray(raw.may_contain || raw.mayContain),
    recommendation_queries: toArray(raw.recommendation_queries || raw.recommendationQueries),
    recommendation_items: normalizeRecommendationItems(raw.recommendation_items || raw.recommendationItems || raw.alternative_products || raw.alternativeProducts || raw.recommended_products || raw.recommendedProducts || raw.items),
    suitability_note: raw.suitability_note || raw.suitabilityNote || '',
    confidence: raw.confidence || 'low',
    notes: toArray(raw.notes)
  };
}

function normalizeRecommendationItems(value) {
  if (!value) return [];
  const arr = Array.isArray(value) ? value : [value];
  return arr.map((item, index) => {
    if (typeof item === 'string') {
      return { rank: index + 1, name: item, search_query: item, image_query: item, image_url: '', reason: '', allergen_note: '', caution: '' };
    }
    const obj = item && typeof item === 'object' ? item : {};
    const name = obj.name || obj.product_name || obj.productName || obj.search_query || obj.searchQuery || '';
    const searchQuery = obj.search_query || obj.searchQuery || name;
    return {
      rank: Number(obj.rank || index + 1),
      name,
      search_query: searchQuery,
      image_query: obj.image_query || obj.imageQuery || searchQuery || name,
      image_url: obj.image_url || obj.imageUrl || '',
      image_source: obj.image_source || obj.imageSource || '',
      reason: obj.reason || obj.description || '',
      allergen_note: obj.allergen_note || obj.allergenNote || '',
      caution: obj.caution || obj.warning || '',
      rakuten_item_name: obj.rakuten_item_name || obj.rakutenItemName || '',
      rakuten_item_url: obj.rakuten_item_url || obj.rakutenItemUrl || '',
      rakuten_affiliate_url: obj.rakuten_affiliate_url || obj.rakutenAffiliateUrl || ''
    };
  }).filter(item => item.name || item.search_query);
}

function applyLocalAllergenJudgement(res) {
  const restricted = userAllergens();
  const allText = [res.ocr_text, res.ingredients, res.allergy_label, res.translated_ingredients, ...(res.detected_allergens || []), ...(res.matches || [])].join('\n');
  const localMatches = restricted.filter(item => normalizeText(allText).includes(normalizeText(item)));
  const mayContainPatterns = userLang() === 'ja' ? ['同一工場','製造ライン','含む可能性','コンタミ','本品製造工場','共通の設備','同じ設備'] : ['may contain','facility','same line','shared equipment','processed in','manufactured in a facility'];
  const localMay = mayContainPatterns.filter(p => normalizeText(allText).includes(normalizeText(p)));
  const matches = uniqueArray([...(res.matches || []), ...localMatches]);
  const may_contain = uniqueArray([...(res.may_contain || []), ...localMay]);
  let status = res.status;
  if (matches.length > 0) status = 'danger';
  else if (may_contain.length > 0 && status !== 'danger') status = 'warning';
  else if (!res.ocr_text && !res.ingredients && !res.allergy_label) status = 'unknown';
  else if (!['danger', 'warning', 'unknown'].includes(status)) status = 'clear';
  const recommendation_queries = ensureRecommendationQueries(res.recommendation_queries, res.category, restricted, res.recommendation_items);
  const recommendation_items = ensureRecommendationItems(res.recommendation_items, recommendation_queries, { ...res, status, matches, may_contain }, restricted);
  return { ...res, status, matches, may_contain, recommendation_queries, recommendation_items };
}

function ensureRecommendationQueries(existing, category, restricted, items = []) {
  const arr = uniqueArray([...toArray(existing), ...toArray(items.map(item => item.search_query || item.name))]);
  if (arr.length) return arr.slice(0, 12);
  const cat = category && category !== '不明' ? category : (userLang() === 'ja' ? '食品' : 'food');
  const base = restricted.length ? restricted : (userLang() === 'ja' ? ['アレルギー対応'] : ['allergy friendly']);
  return uniqueArray(base.slice(0, 4).map(x => userLang() === 'ja' ? `${x} 不使用 ${cat}` : `${x} free ${cat}`)).slice(0, 8);
}

function ensureRecommendationItems(existing, queries, analysis = {}, restricted = []) {
  const items = normalizeRecommendationItems(existing).filter(item => isSpecificRecommendationItem(item));
  const fallback = buildContextualRecommendationItems(analysis, restricted);
  const merged = uniqueRecommendationItems([...items, ...fallback]);
  if (merged.length) return merged.slice(0, 12).map((item, index) => ({ ...item, rank: item.rank || index + 1 }));

  return toArray(queries).slice(0, 8).map((query, index) => ({
    rank: index + 1,
    name: query,
    search_query: query,
    image_query: query,
    image_url: '',
    image_source: '',
    reason: userLang() === 'ja' ? '代替商品を探すための検索候補です。' : 'Search candidate for alternative products.',
    allergen_note: userLang() === 'ja' ? '不使用を保証するものではありません。' : 'This does not guarantee allergen-free status.',
    caution: userLang() === 'ja' ? '購入前に原材料表示、アレルギー表示、メーカー公式情報を確認してください。' : 'Verify ingredients, allergy label, and manufacturer information before purchase.'
  }));
}

function isSpecificRecommendationItem(item) {
  if (!item || !(item.name || item.search_query)) return false;
  const name = normalizeText(item.name || '');
  const query = normalizeText(item.search_query || '');
  if (!name) return false;
  const genericJa = ['食品', 'お菓子', '商品', '代替商品', 'アレルギー対応', '不使用'];
  const genericEn = ['food', 'snack', 'product', 'alternative', 'allergyfriendly', 'free'];
  if (name.length <= 2) return false;
  if (genericJa.includes(name) || genericEn.includes(name)) return false;
  if (name === query && /不使用|free|対応|friendly|検索|search/.test(item.name)) return false;
  return true;
}

function uniqueRecommendationItems(items) {
  const seen = new Set();
  const out = [];
  for (const item of items) {
    const key = normalizeText(item.name || item.search_query || '');
    if (!key || seen.has(key)) continue;
    seen.add(key);
    out.push(item);
  }
  return out;
}

function buildContextualRecommendationItems(analysis, restricted) {
  const text = normalizeText([
    analysis.category,
    analysis.product_name,
    analysis.ocr_text,
    analysis.ingredients,
    analysis.allergy_label,
    ...(analysis.matches || []),
    ...(analysis.detected_allergens || []),
    ...restricted
  ].join(' '));
  const wantsNoGelatinApple = /ゼラチン|gelatin|りんご|リンゴ|apple/.test(text);
  const gummyContext = /グミ|キャンディ|飴|あめ|ゼリー|gummy|candy|jelly/.test(text);
  if (wantsNoGelatinApple && gummyContext) return gelatinAppleCandyAlternatives();
  return [];
}

function gelatinAppleCandyAlternatives() {
  if (userLang() === 'ja') {
    return [
      {
        rank: 1,
        name: 'セイカ食品 ボンタンアメ',
        search_query: 'セイカ食品 ボンタンアメ',
        image_query: 'セイカ食品 ボンタンアメ パッケージ',
        image_url: '',
        image_source: '',
        reason: 'もち米、水あめ、砂糖などを使ったロングセラーの飴で、グミのようなもちもちした食感の代替候補です。',
        allergen_note: 'ゼラチン・りんごを避けたい場合の候補です。ただし大豆など他成分の表示確認が必要です。',
        caution: '購入前に原材料表示、アレルギー表示、メーカー公式情報を確認してください。'
      },
      {
        rank: 2,
        name: 'セイカ食品 兵六餅',
        search_query: 'セイカ食品 兵六餅',
        image_query: 'セイカ食品 兵六餅 パッケージ',
        image_url: '',
        image_source: '',
        reason: 'ボンタンアメの姉妹品で、もちもちした食感があり、グミ・キャンディ系の代替候補になります。',
        allergen_note: 'ゼラチン・りんごを避けたい場合の候補です。味や製造時期で表示が変わる可能性があります。',
        caution: '購入前に原材料表示、アレルギー表示、メーカー公式情報を確認してください。'
      },
      {
        rank: 3,
        name: 'ビオクラ 有機グミ コーラ味',
        search_query: 'ビオクラ 有機グミ コーラ',
        image_query: 'ビオクラ 有機グミ コーラ パッケージ',
        image_url: '',
        image_source: '',
        reason: 'ゼラチンの代わりに植物由来原料を使うヴィーガン系グミとして探しやすい候補です。',
        allergen_note: 'フルーツ味はりんご由来原料を含む場合があるため、コーラ味を優先して確認してください。',
        caution: '味違いで原材料が変わるため、必ずコーラ味の原材料表示を確認してください。'
      },
      {
        rank: 4,
        name: '杉本屋製菓 厚切り寒天',
        search_query: '杉本屋 厚切り寒天',
        image_query: '杉本屋製菓 厚切り寒天 パッケージ',
        image_url: '',
        image_source: '',
        reason: '寒天を使ったゼリー・グミに近い食感のお菓子として代替候補になります。',
        allergen_note: 'ミックス味やフルーツ味はりんご等を含む可能性があるため、ぶどう味やコーラ味など個別に確認してください。',
        caution: '購入前に原材料表示、アレルギー表示、メーカー公式情報を確認してください。'
      }
    ];
  }
  return [
    {
      rank: 1,
      name: 'Seika Foods Bontan Ame',
      search_query: 'Seika Foods Bontan Ame',
      image_query: 'Seika Foods Bontan Ame package',
      image_url: '',
      image_source: '',
      reason: 'A chewy candy alternative often searched as a gummy-like snack.',
      allergen_note: 'Candidate for avoiding gelatin and apple, but ingredient labels must be verified.',
      caution: 'Check the product label, allergy label, and official manufacturer information before purchase.'
    },
    {
      rank: 2,
      name: 'Seika Foods Hyoroku Mochi',
      search_query: 'Seika Foods Hyoroku Mochi',
      image_query: 'Seika Foods Hyoroku Mochi package',
      image_url: '',
      image_source: '',
      reason: 'A chewy candy-like product related to Bontan Ame.',
      allergen_note: 'Candidate for avoiding gelatin and apple, but formulations may vary.',
      caution: 'Verify the exact package and manufacturer information before purchase.'
    },
    {
      rank: 3,
      name: 'Biokura Organic Gummy Cola Flavor',
      search_query: 'Biokura Organic Gummy Cola',
      image_query: 'Biokura Organic Gummy Cola package',
      image_url: '',
      image_source: '',
      reason: 'A vegan-style gummy candidate; cola flavor is preferred over fruit flavors.',
      allergen_note: 'Fruit flavors may contain apple-derived ingredients, so verify the cola flavor label.',
      caution: 'Check the flavor-specific ingredients before purchase.'
    },
    {
      rank: 4,
      name: 'Sugimotoya Thick-Cut Kanten',
      search_query: 'Sugimotoya Thick-Cut Kanten',
      image_query: 'Sugimotoya Thick-Cut Kanten package',
      image_url: '',
      image_source: '',
      reason: 'A kanten-based jelly-like snack candidate.',
      allergen_note: 'Avoid mixed fruit flavors unless the ingredients are verified.',
      caution: 'Check the product label and official manufacturer information before purchase.'
    }
  ];
}

async function enrichRecommendationItemsWithRakuten(result, cfg) {
  if (!cfg || !cfg.rakutenApplicationId || !Array.isArray(result.recommendation_items) || !result.recommendation_items.length) {
    return result;
  }
  const items = [];
  for (const item of result.recommendation_items) {
    if (item.image_url) { items.push(item); continue; }
    try {
      const rakuten = await fetchRakutenFirstItem(item.search_query || item.name, cfg);
      if (rakuten) {
        items.push({
          ...item,
          image_url: rakuten.imageUrl || item.image_url,
          image_source: rakuten.imageUrl ? t().photoSourceRakuten : item.image_source,
          rakuten_item_name: rakuten.itemName || item.rakuten_item_name,
          rakuten_item_url: rakuten.itemUrl || item.rakuten_item_url,
          rakuten_affiliate_url: rakuten.affiliateUrl || item.rakuten_affiliate_url
        });
      } else {
        items.push(item);
      }
    } catch (e) {
      console.warn('Rakuten image fetch failed:', e);
      items.push(item);
    }
  }
  return { ...result, recommendation_items: items };
}

async function fetchRakutenFirstItem(query, cfg) {
  const endpoint = cfg.rakutenApiEndpoint || DEFAULT_CONFIG.rakutenApiEndpoint;
  const url = new URL(endpoint);
  url.searchParams.set('format', 'json');
  url.searchParams.set('keyword', query);
  url.searchParams.set('applicationId', cfg.rakutenApplicationId);
  url.searchParams.set('hits', '1');
  url.searchParams.set('imageFlag', '1');
  if (cfg.rakutenAffiliateId) url.searchParams.set('affiliateId', cfg.rakutenAffiliateId);
  if (cfg.rakutenAccessKey) url.searchParams.set('accessKey', cfg.rakutenAccessKey);
  const res = await fetch(url.toString());
  if (!res.ok) return null;
  const json = await res.json();
  const first = json?.Items?.[0]?.Item;
  if (!first) return null;
  const medium = first.mediumImageUrls && first.mediumImageUrls[0];
  const small = first.smallImageUrls && first.smallImageUrls[0];
  const imageUrl = typeof medium === 'string' ? medium : (medium?.imageUrl || (typeof small === 'string' ? small : small?.imageUrl) || '');
  return { itemName: first.itemName || '', itemUrl: first.itemUrl || '', affiliateUrl: first.affiliateUrl || '', imageUrl };
}

function renderResult(res) {
  const status = getStatusInfo(res.status);
  const cfg = currentConfig || DEFAULT_CONFIG;
  document.getElementById('result-area').innerHTML = `
    <div class="alert-box ${status.className}">
      <span style="font-size:64px;">${status.emoji}</span>
      <h2>${status.label}</h2>
      <p><strong>${escapeHtml(res.product_name)}</strong></p>
      <p>${escapeHtml(res.suitability_note || cfg.safetyDisclaimer || t().disclaimer)}</p>
      <div>${res.matches.length ? res.matches.map(m => `<span class="tag tag-danger">${escapeHtml(m)}</span>`).join('') : `<span class="tag tag-success">${escapeHtml(t().noMatches)}</span>`}</div>
      <div class="notice ${res.status === 'danger' ? 'danger-notice' : res.status === 'warning' ? 'warning-notice' : ''}">${escapeHtml(cfg.safetyDisclaimer || t().disclaimer)}</div>
    </div>
    <div class="card"><h3>判定結果</h3><p><strong>${t().product}:</strong> ${escapeHtml(res.product_name)}</p><p><strong>${t().category}:</strong> ${escapeHtml(res.category)}</p><p><strong>Confidence:</strong> ${escapeHtml(res.confidence)}</p></div>
    <div class="card"><h3>${t().detected}</h3><div>${res.detected_allergens.length ? res.detected_allergens.map(m => `<span class="tag">${escapeHtml(m)}</span>`).join('') : `<span class="tag">${escapeHtml(t().noMatches)}</span>`}</div><h3 style="margin-top:16px;">${t().warnings}</h3><div>${res.may_contain.length ? res.may_contain.map(m => `<span class="tag tag-warning">${escapeHtml(m)}</span>`).join('') : `<span class="tag">${escapeHtml(t().noMatches)}</span>`}</div></div>
    <details class="card" open><summary style="cursor:pointer;font-weight:800;">${t().ingredients}</summary><div class="mono-box" style="margin-top:10px;">${escapeHtml(res.translated_ingredients || res.ingredients)}</div></details>
    <details class="card"><summary style="cursor:pointer;font-weight:800;">${t().ocr}</summary><div class="mono-box" style="margin-top:10px;">${escapeHtml(res.ocr_text)}</div></details>
    ${renderRecommendations(res.recommendation_queries, res.category, res.recommendation_items)}
    <details class="card"><summary style="cursor:pointer;font-weight:800;">${t().raw}</summary><pre class="mono-box" style="margin-top:10px;">${escapeHtml(JSON.stringify(res, null, 2))}</pre></details>
  `;
}

function updatePreviewResultOverlay(res, options = {}) {
  const el = document.getElementById('preview-result-overlay');
  if (!el || !res) return;
  const status = getStatusInfo(res.status);
  const overlayClass = res.status === 'danger' ? 'overlay-danger' : res.status === 'warning' ? 'overlay-warning' : res.status === 'clear' ? 'overlay-safe' : 'overlay-unknown';
  const matches = toArray(res.matches);
  const detected = toArray(res.detected_allergens);
  const tags = matches.length ? matches : detected.slice(0, 4);
  const tagHtml = tags.length
    ? tags.map(m => `<span class="overlay-tag">${escapeHtml(m)}</span>`).join('')
    : `<span class="overlay-tag">${escapeHtml(t().noMatches)}</span>`;
  const product = res.product_name && res.product_name !== '不明' ? `<p><strong>${escapeHtml(res.product_name)}</strong></p>` : '';
  const progress = options.pendingRecommendations ? `<div class="overlay-progress">${escapeHtml(userLang() === 'ja' ? '関連商品検索を続行中...' : 'Finding related products...')}</div>` : '';
  el.className = `preview-result-overlay show ${overlayClass}`;
  el.innerHTML = `
    <h2>${status.emoji} ${escapeHtml(status.label)}</h2>
    ${product}
    <p>${escapeHtml(res.suitability_note || t().disclaimer)}</p>
    <div class="overlay-tags">${tagHtml}</div>
    ${progress}
  `;
}

function setPreviewResultProgress(text) {
  const el = document.getElementById('preview-result-overlay');
  if (!el || !el.classList.contains('show')) return;
  let progress = el.querySelector('.overlay-progress');
  if (!progress) {
    progress = document.createElement('div');
    progress.className = 'overlay-progress';
    el.appendChild(progress);
  }
  progress.textContent = text || '';
}

function clearPreviewResultOverlay() {
  const el = document.getElementById('preview-result-overlay');
  if (!el) return;
  el.className = 'preview-result-overlay';
  el.innerHTML = '';
}

function getStatusInfo(status) {
  if (status === 'danger') return { label: t().critical, emoji: '😫', className: 'alert-critical' };
  if (status === 'warning') return { label: t().warning, emoji: '⚠️', className: 'alert-warning' };
  if (status === 'clear') return { label: t().safe, emoji: '😊', className: 'alert-safe' };
  return { label: t().unknown, emoji: '❓', className: 'alert-unknown' };
}

function renderRecommendations(queries, category, items = []) {
  const cfg = currentConfig || DEFAULT_CONFIG;
  const productItems = ensureRecommendationItems(items, queries);
  if (!productItems.length) return '';
  return `<div class="recommendations"><h3>${t().recommendations}</h3>${productItems.map(item => renderRecommendationItem(item, category, cfg)).join('')}</div>`;
}

function renderRecommendationItem(item, category, cfg) {
  const query = item.search_query || item.name || item.image_query;
  const amazonUrl = buildAmazonUrl(query, cfg);
  const rakutenUrl = buildRakutenUrl(query, cfg);
  const imageSearchUrl = buildImageSearchUrl(item.image_query || query);
  const customLinks = (cfg.customLinks || [])
    .filter(x => x.enabled && x.urlTemplate)
    .map(x => `<a class="link-button custom-link" href="${escapeAttribute(fillTemplate(x.urlTemplate, query, cfg))}" target="_blank" rel="noopener noreferrer sponsored" onclick="trackAffiliateClick('custom','${escapeAttribute(query)}',this.href,'${escapeAttribute(category)}')">${escapeHtml(x.label || t().custom)}</a>`)
    .join('');
  const fallbackThumbUrl = buildImageThumbnailUrl(item.image_query || query);
  const photoHtml = item.image_url
    ? `<img class="product-photo" src="${escapeAttribute(item.image_url)}" alt="${escapeAttribute(item.name)}" loading="lazy" referrerpolicy="no-referrer" onerror="this.onerror=null;this.src='${escapeAttribute(fallbackThumbUrl)}';"><small>${escapeHtml(item.image_source || '')}</small>`
    : `<a class="product-photo-link" href="${escapeAttribute(imageSearchUrl)}" target="_blank" rel="noopener noreferrer"><img class="product-photo" src="${escapeAttribute(fallbackThumbUrl)}" alt="${escapeAttribute(item.name)}" loading="lazy" referrerpolicy="no-referrer" onerror="this.style.display='none';this.parentElement.classList.add('photo-error');"><span class="photo-fallback-label">${escapeHtml(t().imageSearch)}</span></a><small>${escapeHtml(t().photoSourceSearch)}</small>`;
  return `<div class="recommendation-card product-card">
    <div class="product-image-wrap">${photoHtml}</div>
    <div class="product-detail">
      <h4>${escapeHtml(item.rank ? `${item.rank}. ${item.name}` : item.name)}</h4>
      <p><strong>${escapeHtml(t().searchKeyword)}:</strong> ${escapeHtml(query)}</p>
      ${item.reason ? `<p><strong>${escapeHtml(t().reason)}:</strong> ${escapeHtml(item.reason)}</p>` : ''}
      ${item.allergen_note ? `<p><strong>${escapeHtml(t().allergenNote)}:</strong> ${escapeHtml(item.allergen_note)}</p>` : ''}
      ${item.caution ? `<p><strong>${escapeHtml(t().caution)}:</strong> ${escapeHtml(item.caution)}</p>` : ''}
      <div class="recommendation-actions"><a class="link-button amazon-link" href="${escapeAttribute(amazonUrl)}" target="_blank" rel="noopener noreferrer sponsored" onclick="trackAffiliateClick('amazon','${escapeAttribute(query)}',this.href,'${escapeAttribute(category)}')">${t().amazon}</a><a class="link-button rakuten-link" href="${escapeAttribute(rakutenUrl)}" target="_blank" rel="noopener noreferrer sponsored" onclick="trackAffiliateClick('rakuten','${escapeAttribute(query)}',this.href,'${escapeAttribute(category)}')">${t().rakuten}</a>${customLinks}</div>
    </div>
  </div>`;
}

function buildAmazonUrl(query, cfg) { return fillTemplate(cfg.amazonSearchTemplate || DEFAULT_CONFIG.amazonSearchTemplate, query, cfg); }
function buildRakutenUrl(query, cfg) { return fillTemplate(cfg.rakutenSearchTemplate || DEFAULT_CONFIG.rakutenSearchTemplate, query, cfg); }
function buildImageSearchUrl(query) { return `https://www.google.com/search?tbm=isch&q=${encodeURIComponent(query)}`; }
function buildImageThumbnailUrl(query) { return `https://tse1.mm.bing.net/th?q=${encodeURIComponent(query)}&w=420&h=320&c=7&rs=1&p=0&o=5&pid=1.7`; }
function fillTemplate(template, query, cfg) {
  const domain = String(cfg.amazonDomain || 'amazon.co.jp').replace(/^https?:\/\//, '').replace(/^www\./, '').replace(/\/.*$/, '');
  return String(template)
    .replaceAll('{query}', encodeURIComponent(query))
    .replaceAll('{queryRaw}', query)
    .replaceAll('{domain}', domain)
    .replaceAll('{tag}', encodeURIComponent(cfg.amazonAssociateTag || ''))
    .replaceAll('{rakutenAffiliateId}', encodeURIComponent(cfg.rakutenAffiliateId || ''));
}

async function trackAffiliateClick(provider, keyword, url, category) {
  try { await logAffiliateClick({ provider, keyword, url, category, allergens: userAllergens() }); } catch (e) { console.warn(e); }
}
window.trackAffiliateClick = trackAffiliateClick;

function showLoading(text) { const el = document.getElementById('loading-overlay'); if (el) { el.style.display = 'flex'; document.getElementById('ui-loading-text').textContent = text || ''; } }
function hideLoading() { const el = document.getElementById('loading-overlay'); if (el) el.style.display = 'none'; }

function resizeImageDataUrl(dataUrl, maxWidth, quality) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => {
      let w = img.width; let h = img.height;
      if (w > maxWidth) { h *= maxWidth / w; w = maxWidth; }
      const canvas = document.createElement('canvas');
      canvas.width = Math.round(w); canvas.height = Math.round(h);
      canvas.getContext('2d').drawImage(img, 0, 0, canvas.width, canvas.height);
      resolve({ dataUrl: canvas.toDataURL('image/jpeg', quality), mimeType: 'image/jpeg' });
    };
    img.onerror = reject;
    img.src = dataUrl;
  });
}

function parseJsonFromModelText(text) {
  const cleaned = String(text || '').replace(/^```json\s*/i, '').replace(/^```\s*/i, '').replace(/```$/i, '').trim();
  try { return JSON.parse(cleaned); } catch (e) {
    const match = cleaned.match(/\{[\s\S]*\}/);
    if (match) return JSON.parse(match[0]);
    throw e;
  }
}

function renderAdPlaceholder(slot) {
  const container = document.querySelector(`[data-ad-slot="${slot}"]`);
  if (!container) return;
  getConfig().then(cfg => {
    if (cfg.adsenseEnabled && cfg.adsensePublisherId) {
      container.innerHTML = `<div class="ad-placeholder">AdSense広告枠: ${escapeHtml(slot)}<br>Publisher: ${escapeHtml(cfg.adsensePublisherId)}</div>`;
    } else {
      container.innerHTML = `<div class="ad-placeholder">広告枠 / Ad Placeholder</div>`;
    }
  });
}


// Fast allergen check + judgement comparison overrides.
const FAST_SCAN_SYSTEM_PROMPT_JA = `あなたは食品表示OCRとアレルゲン抽出を行う補助AIです。
画像から商品名、カテゴリ、原材料、アレルギー表示、注意喚起文を読み取ってください。
代替商品の提案や商品検索は行わないでください。
出力は必ずJSONのみです。

JSON:
{
  "status": "danger | warning | clear | unknown",
  "product_name": "商品名。不明なら不明",
  "category": "カテゴリ。不明なら不明",
  "ocr_text": "読み取った全文",
  "ingredients": "原材料表示",
  "allergy_label": "アレルギー表示",
  "translated_ingredients": "原材料の整理",
  "detected_allergens": ["検出したアレルゲン"],
  "matches": [],
  "may_contain": ["同一工場、製造ライン、含む可能性など"],
  "recommendation_queries": [],
  "recommendation_items": [],
  "suitability_note": "OCRで読み取れた範囲の注意",
  "confidence": "high | medium | low",
  "notes": []
}`;

const FAST_SCAN_SYSTEM_PROMPT_EN = `You are an assistant for OCR and allergen extraction from food labels.
Read the product name, category, ingredients, allergy label, and caution statements from the image.
Do not recommend alternative products or search terms.
Return JSON only.

JSON:
{
  "status": "danger | warning | clear | unknown",
  "product_name": "Product name, or unknown",
  "category": "Category, or unknown",
  "ocr_text": "Full OCR text",
  "ingredients": "Ingredients",
  "allergy_label": "Allergy label",
  "translated_ingredients": "Organized ingredients",
  "detected_allergens": ["Detected allergens"],
  "matches": [],
  "may_contain": ["May contain / same factory / shared line warnings"],
  "recommendation_queries": [],
  "recommendation_items": [],
  "suitability_note": "Caution based on OCR only",
  "confidence": "high | medium | low",
  "notes": []
}`;

const GEMINI_JUDGEMENT_SYSTEM_PROMPT_JA = `あなたは食品アレルギー判定を補助するAIです。
与えられたOCRテキストとユーザーの避けたい成分を照合してください。
代替商品や検索候補は返さないでください。
安全断定は禁止です。出力はJSONのみです。

JSON:
{
  "status": "danger | warning | clear | unknown",
  "detected_allergens": ["OCRテキストから検出したアレルゲン"],
  "matches": ["ユーザーの避けたい成分と一致したもの"],
  "may_contain": ["同一工場、製造ライン、含む可能性など"],
  "suitability_note": "判定理由。安全断定は禁止",
  "confidence": "high | medium | low"
}`;

const GEMINI_JUDGEMENT_SYSTEM_PROMPT_EN = `You are an AI assistant for food allergy judgement.
Compare the OCR text with the user's restricted ingredients.
Do not return recommendations or search terms.
Do not guarantee safety. Return JSON only.

JSON:
{
  "status": "danger | warning | clear | unknown",
  "detected_allergens": ["Allergens detected in OCR text"],
  "matches": ["Items matching the user's restrictions"],
  "may_contain": ["May contain / same factory / shared line warnings"],
  "suitability_note": "Reason. Do not guarantee safety.",
  "confidence": "high | medium | low"
}`;

async function analyze(base64, mimeType) {
  currentConfig = await getConfig();
  const cfg = currentConfig || DEFAULT_CONFIG;
  try {
    if (cfg.fastAllergenCheckEnabled !== false) {
      showLoading(userLang() === 'ja' ? '含有判定中...' : 'Checking allergens...');
      let fast = await runFastAllergenCheck(base64, mimeType, cfg);
      fast = normalizeAnalysisResult(fast);
      fast = await applyConfiguredJudgement(fast, cfg);
      fast = { ...fast, recommendation_queries: [], recommendation_items: [] };

      // 判定だけを先に表示。関連商品検索で画面をブロックしない。
      renderResult(fast, { pendingRecommendations: true });
      hideLoading();
      setPreviewResultProgress(userLang() === 'ja' ? '関連商品検索を続行中...' : 'Finding related products...');

      const finalGemini = cfg.requestMode === 'mock' ? await analyzeMock() : await analyzeGeminiRecommendations(base64, mimeType, cfg, fast);
      let finalResult = mergeFinalAnalysis(fast, normalizeAnalysisResult(finalGemini));
      finalResult = await applyConfiguredJudgement(finalResult, cfg);
      finalResult = await enrichRecommendationItemsWithRakuten(finalResult, cfg);
      renderResult(finalResult, { pendingRecommendations: false });
      await logRecommendationKeywords(finalResult);
      return;
    }

    showLoading(t().loading);
    let result = cfg.requestMode === 'mock' ? await analyzeMock() : await analyzeGeminiDirect(base64, mimeType, cfg);
    result = normalizeAnalysisResult(result);
    result = await applyConfiguredJudgement(result, cfg);
    result = await enrichRecommendationItemsWithRakuten(result, cfg);
    renderResult(result);
    await logRecommendationKeywords(result);
  } catch (err) {
    console.error(err);
    alert((err && err.message) || String(err));
  } finally {
    hideLoading();
  }
}
async function logRecommendationKeywords(result) {
  const keywords = uniqueArray([...(result.recommendation_queries || []), ...(result.recommendation_items || []).map(item => item.search_query || item.name).filter(Boolean)]);
  for (const q of keywords) {
    await logSearchEvent({ keyword: q, category: result.category, allergens: userAllergens(), source: 'scan' });
  }
}

async function runFastAllergenCheck(base64, mimeType, cfg) {
  const engine = cfg.ocrEngine || 'gemini';
  if (cfg.requestMode === 'mock' || engine === 'mock') {
    const mock = await analyzeMock();
    return { ...mock, recommendation_queries: [], recommendation_items: [] };
  }
  if (engine === 'tesseract') {
    return await analyzeTesseractOcr(base64, mimeType);
  }
  return await analyzeGeminiFastScan(base64, mimeType, cfg);
}

async function analyzeGeminiFastScan(base64, mimeType, cfg) {
  if (!cfg.geminiApiKey) throw new Error(t().apiMissing);
  const model = cfg.geminiModel || 'gemini-2.0-flash';
  const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(cfg.geminiApiKey)}`;
  const systemPrompt = userLang() === 'ja' ? FAST_SCAN_SYSTEM_PROMPT_JA : FAST_SCAN_SYSTEM_PROMPT_EN;
  const body = {
    systemInstruction: { parts: [{ text: systemPrompt }] },
    contents: [{
      role: 'user',
      parts: [
        { text: `ユーザーが避けたい成分・アレルゲン・食事制限: ${userAllergens().join(', ') || '未設定'}\n画像の食品表示を読み取ってJSONのみ返してください。代替商品は返さないでください。` },
        { inlineData: { mimeType, data: base64 } }
      ]
    }],
    generationConfig: { temperature: 0, topP: 0.4, topK: 20, responseMimeType: 'application/json' }
  };
  const res = await fetch(endpoint, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
  const json = await res.json();
  if (!res.ok) throw new Error(json?.error?.message || `Gemini API error: ${res.status}`);
  const text = json?.candidates?.[0]?.content?.parts?.map(p => p.text || '').join('\n').trim();
  return parseJsonFromModelText(text);
}

let tesseractLoadingPromise = null;

function loadTesseractIfNeeded() {
  if (window.Tesseract) return Promise.resolve();
  if (tesseractLoadingPromise) return tesseractLoadingPromise;
  tesseractLoadingPromise = new Promise((resolve, reject) => {
    const script = document.createElement('script');
    script.src = 'https://cdn.jsdelivr.net/npm/tesseract.js@5/dist/tesseract.min.js';
    script.async = true;
    script.onload = resolve;
    script.onerror = () => reject(new Error('Tesseract.js を読み込めませんでした。OCR EngineはGeminiを推奨します。'));
    document.head.appendChild(script);
  });
  return tesseractLoadingPromise;
}

async function analyzeTesseractOcr(base64, mimeType) {
  await loadTesseractIfNeeded();
  if (!window.Tesseract) {
    throw new Error('Tesseract.js が読み込まれていません。OCR EngineをGeminiに変更してください。');
  }
  const dataUrl = `data:${mimeType || 'image/jpeg'};base64,${base64}`;
  const ocrDataUrl = await preprocessForBrowserOcr(dataUrl);
  const lang = userLang() === 'ja' ? 'jpn+eng' : 'eng+jpn';
  const result = await Tesseract.recognize(ocrDataUrl, lang);
  const text = result?.data?.text || '';
  return buildLocalOcrResult(text, 'tesseract');
}

async function preprocessForBrowserOcr(dataUrl) {
  return new Promise(resolve => {
    const img = new Image();
    img.onload = () => {
      const maxWidth = 1800;
      let w = img.naturalWidth || img.width;
      let h = img.naturalHeight || img.height;
      if (w > maxWidth) { h *= maxWidth / w; w = maxWidth; }
      const canvas = document.createElement('canvas');
      canvas.width = Math.round(w);
      canvas.height = Math.round(h);
      const ctx = canvas.getContext('2d', { willReadFrequently: true });
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
      try {
        const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
        const data = imageData.data;
        for (let i = 0; i < data.length; i += 4) {
          const gray = 0.299 * data[i] + 0.587 * data[i + 1] + 0.114 * data[i + 2];
          const v = gray < 150 ? Math.max(0, gray - 28) : Math.min(255, gray + 22);
          data[i] = data[i + 1] = data[i + 2] = v;
        }
        ctx.putImageData(imageData, 0, 0);
        resolve(canvas.toDataURL('image/png'));
      } catch (e) {
        resolve(dataUrl);
      }
    };
    img.onerror = () => resolve(dataUrl);
    img.src = dataUrl;
  });
}
function buildLocalOcrResult(text, source = 'local') {
  const lineText = String(text || '');
  const ingredients = extractLikelyIngredients(lineText);
  return {
    status: 'unknown',
    product_name: '不明',
    category: '不明',
    ocr_text: lineText,
    ingredients: ingredients,
    allergy_label: extractLikelyAllergyLabel(lineText),
    translated_ingredients: ingredients || lineText,
    detected_allergens: detectKnownAllergens(lineText),
    matches: [],
    may_contain: [],
    recommendation_queries: [],
    recommendation_items: [],
    suitability_note: source === 'tesseract' ? 'ブラウザ内OCRで読み取った文字から判定しています。' : 'OCRテキストから判定しています。',
    confidence: text ? 'medium' : 'low',
    notes: []
  };
}

function extractLikelyIngredients(text) {
  const value = String(text || '');
  const m = value.match(/(?:原材料名|原材料|Ingredients?)[:：\s]*([\s\S]{0,500})/i);
  if (!m) return '';
  return m[1].split(/\n(?:内容量|賞味期限|保存方法|栄養成分|製造者|販売者|JAN|アレルギー|本品)/)[0].trim();
}

function extractLikelyAllergyLabel(text) {
  const value = String(text || '');
  const lines = value.split(/\n/).filter(line => /含む|アレルギー|allergen|contains|may contain|同一工場|製造ライン/i.test(line));
  return lines.join('\n');
}

function detectKnownAllergens(text) {
  const known = ['小麦','乳','卵','えび','かに','そば','落花生','ピーナッツ','くるみ','カシューナッツ','大豆','ごま','アーモンド','オレンジ','キウイ','牛肉','鶏肉','豚肉','さけ','さば','いか','いくら','バナナ','もも','やまいも','りんご','リンゴ','ゼラチン','グルテン','wheat','milk','egg','shrimp','crab','buckwheat','peanut','walnut','cashew','soy','sesame','almond','orange','kiwi','beef','chicken','pork','salmon','mackerel','squid','banana','peach','apple','gelatin','gluten'];
  const norm = normalizeText(text);
  return uniqueArray(known.filter(item => norm.includes(normalizeText(item))));
}

async function applyConfiguredJudgement(result, cfg) {
  const local = applyLocalAllergenJudgement(result);
  const mode = cfg.judgementEngine || 'local';
  if (mode === 'local') {
    return { ...local, judgement_engine_used: 'local', judgement_comparison: null };
  }

  let geminiJudgement = null;
  if (cfg.requestMode === 'mock') {
    geminiJudgement = {
      status: result.status,
      detected_allergens: result.detected_allergens,
      matches: result.matches,
      may_contain: result.may_contain,
      suitability_note: result.suitability_note,
      confidence: result.confidence
    };
  } else {
    geminiJudgement = await judgeWithGeminiText(result, cfg);
  }

  const geminiResult = {
    ...result,
    status: geminiJudgement.status || result.status,
    detected_allergens: toArray(geminiJudgement.detected_allergens || geminiJudgement.detectedAllergens || result.detected_allergens),
    matches: toArray(geminiJudgement.matches || result.matches),
    may_contain: toArray(geminiJudgement.may_contain || geminiJudgement.mayContain || result.may_contain),
    suitability_note: geminiJudgement.suitability_note || geminiJudgement.suitabilityNote || result.suitability_note,
    confidence: geminiJudgement.confidence || result.confidence
  };

  if (mode === 'gemini') {
    return { ...geminiResult, judgement_engine_used: 'gemini', judgement_comparison: { local: summarizeJudgement(local), gemini: summarizeJudgement(geminiResult) } };
  }

  return {
    ...local,
    judgement_engine_used: 'compare',
    judgement_comparison: {
      local: summarizeJudgement(local),
      gemini: summarizeJudgement(geminiResult),
      same_status: local.status === geminiResult.status,
      same_matches: normalizeText((local.matches || []).join(',')) === normalizeText((geminiResult.matches || []).join(','))
    }
  };
}

async function judgeWithGeminiText(result, cfg) {
  if (!cfg.geminiApiKey) throw new Error(t().apiMissing);
  const model = cfg.geminiModel || 'gemini-2.0-flash';
  const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(cfg.geminiApiKey)}`;
  const systemPrompt = userLang() === 'ja' ? GEMINI_JUDGEMENT_SYSTEM_PROMPT_JA : GEMINI_JUDGEMENT_SYSTEM_PROMPT_EN;
  const body = {
    systemInstruction: { parts: [{ text: systemPrompt }] },
    contents: [{
      role: 'user',
      parts: [{
        text: `ユーザーが避けたい成分・アレルゲン・食事制限: ${userAllergens().join(', ') || '未設定'}\n\nOCRテキスト:\n${result.ocr_text || result.ingredients || result.allergy_label || ''}`
      }]
    }],
    generationConfig: { temperature: 0, topP: 0.4, topK: 20, responseMimeType: 'application/json' }
  };
  const res = await fetch(endpoint, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
  const json = await res.json();
  if (!res.ok) throw new Error(json?.error?.message || `Gemini judgement error: ${res.status}`);
  const text = json?.candidates?.[0]?.content?.parts?.map(p => p.text || '').join('\n').trim();
  return parseJsonFromModelText(text);
}

function summarizeJudgement(res) {
  return {
    status: res.status,
    matches: toArray(res.matches),
    may_contain: toArray(res.may_contain),
    detected_allergens: toArray(res.detected_allergens),
    confidence: res.confidence || 'low',
    note: res.suitability_note || ''
  };
}

async function analyzeGeminiRecommendations(base64, mimeType, cfg, fastResult) {
  if (!cfg.geminiApiKey) throw new Error(t().apiMissing);
  const model = cfg.geminiModel || 'gemini-2.0-flash';
  const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(cfg.geminiApiKey)}`;
  const systemPrompt = userLang() === 'ja' ? cfg.systemPromptJa : cfg.systemPromptEn;
  const context = `先に出た含有判定:
status=${fastResult.status}
product_name=${fastResult.product_name || ''}
category=${fastResult.category || ''}
matches=${(fastResult.matches || []).join(', ')}
detected_allergens=${(fastResult.detected_allergens || []).join(', ')}
may_contain=${(fastResult.may_contain || []).join(', ')}
ingredients=${fastResult.ingredients || fastResult.translated_ingredients || ''}
allergy_label=${fastResult.allergy_label || ''}

OCRテキスト:
${fastResult.ocr_text || ''}
`;
  const prompt = `ユーザー言語: ${userLang() === 'ja' ? 'Japanese' : 'English'}
ユーザーが避けたい成分・アレルゲン・食事制限: ${userAllergens().join(', ') || '未設定'}

下記の先行判定を尊重して、JSONのみ返してください。
画像OCRはすでに完了しています。含有判定をやり直さず、関連商品検索用の具体的な商品候補 recommendation_items と recommendation_queries を中心に返してください。
recommendation_items は最大4件。各 item は name, search_query, image_query, reason, allergen_note, caution を含めてください。
安全断定は禁止。購入・飲食前の表示確認を促してください。

${context}`;
  const parts = [{ text: prompt }];
  // OCRテキストが取れなかった場合だけ画像を再送して補完する。
  if (!(fastResult.ocr_text || fastResult.ingredients || fastResult.allergy_label) && base64) {
    parts.push({ inlineData: { mimeType, data: base64 } });
  }
  const body = {
    systemInstruction: { parts: [{ text: systemPrompt }] },
    contents: [{ role: 'user', parts }],
    generationConfig: { temperature: 0.2, topP: 0.75, topK: 30, responseMimeType: 'application/json' }
  };
  const res = await fetch(endpoint, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
  const json = await res.json();
  if (!res.ok) throw new Error(json?.error?.message || `Gemini API error: ${res.status}`);
  const text = json?.candidates?.[0]?.content?.parts?.map(p => p.text || '').join('\n').trim();
  return parseJsonFromModelText(text);
}
function mergeFinalAnalysis(fast, rec) {
  const statusFields = {
    status: fast.status,
    matches: fast.matches,
    may_contain: fast.may_contain,
    detected_allergens: uniqueArray([...(fast.detected_allergens || []), ...(rec.detected_allergens || [])]),
    judgement_engine_used: fast.judgement_engine_used,
    judgement_comparison: fast.judgement_comparison
  };
  return {
    ...fast,
    ...rec,
    product_name: rec.product_name && rec.product_name !== '不明' ? rec.product_name : fast.product_name,
    category: rec.category && rec.category !== '不明' ? rec.category : fast.category,
    ocr_text: rec.ocr_text || fast.ocr_text,
    ingredients: rec.ingredients || fast.ingredients,
    allergy_label: rec.allergy_label || fast.allergy_label,
    translated_ingredients: rec.translated_ingredients || fast.translated_ingredients,
    suitability_note: fast.suitability_note || rec.suitability_note,
    confidence: fast.confidence || rec.confidence,
    ...statusFields
  };
}

function applyLocalAllergenJudgement(res) {
  const restricted = userAllergens();
  const allText = [res.ocr_text, res.ingredients, res.allergy_label, res.translated_ingredients, ...(res.detected_allergens || []), ...(res.matches || [])].join('\n');
  const localMatches = [];
  for (const item of restricted) {
    const patterns = allergenPatterns(item);
    if (patterns.some(p => normalizeText(allText).includes(normalizeText(p)))) {
      localMatches.push(item);
    }
  }
  const mayContainPatterns = userLang() === 'ja' ? ['同一工場','製造ライン','含む可能性','コンタミ','本品製造工場','共通の設備','同じ設備'] : ['may contain','facility','same line','shared equipment','processed in','manufactured in a facility'];
  const localMay = mayContainPatterns.filter(p => normalizeText(allText).includes(normalizeText(p)));
  const matches = uniqueArray([...(res.matches || []), ...localMatches]);
  const may_contain = uniqueArray([...(res.may_contain || []), ...localMay]);
  let status = res.status;
  if (matches.length > 0) status = 'danger';
  else if (may_contain.length > 0 && status !== 'danger') status = 'warning';
  else if (!res.ocr_text && !res.ingredients && !res.allergy_label) status = 'unknown';
  else if (!['danger', 'warning', 'unknown'].includes(status)) status = 'clear';
  const recommendation_queries = ensureRecommendationQueries(res.recommendation_queries, res.category, restricted, res.recommendation_items);
  const recommendation_items = ensureRecommendationItems(res.recommendation_items, recommendation_queries, { ...res, status, matches, may_contain }, restricted);
  return { ...res, status, matches, may_contain, recommendation_queries, recommendation_items };
}

function allergenPatterns(item) {
  const key = normalizeText(item);
  const dict = {
    '小麦': ['小麦', '小麦粉', 'こむぎ', 'グルテン', 'パン粉', 'wheat', 'gluten', 'flour'],
    'グルテン': ['グルテン', '小麦', 'wheat', 'gluten'],
    '乳': ['乳', '乳成分', '牛乳', '脱脂粉乳', '全粉乳', 'バター', 'チーズ', 'ホエイ', 'カゼイン', 'milk', 'dairy', 'whey', 'casein', 'butter', 'cheese'],
    '卵': ['卵', 'たまご', '玉子', 'egg', 'albumen'],
    'りんご': ['りんご', 'リンゴ', '林檎', '濃縮りんご果汁', 'アップル', 'apple'],
    'ゼラチン': ['ゼラチン', 'gelatin', 'gelatine'],
    '大豆': ['大豆', 'soy', 'soybean'],
    '落花生': ['落花生', 'ピーナッツ', 'peanut'],
    'ピーナッツ': ['落花生', 'ピーナッツ', 'peanut'],
    'えび': ['えび', 'エビ', '海老', 'shrimp', 'prawn'],
    'かに': ['かに', 'カニ', '蟹', 'crab'],
    'そば': ['そば', '蕎麦', 'buckwheat'],
    'くるみ': ['くるみ', '胡桃', 'walnut'],
    'カシューナッツ': ['カシューナッツ', 'cashew'],
    'アーモンド': ['アーモンド', 'almond'],
    'ごま': ['ごま', '胡麻', 'sesame']
  };
  const enDict = {
    'wheat': dict['小麦'], 'gluten': dict['グルテン'], 'milk': dict['乳'], 'dairy': dict['乳'], 'egg': dict['卵'],
    'apple': dict['りんご'], 'gelatin': dict['ゼラチン'], 'soy': dict['大豆'], 'peanut': dict['落花生'],
    'shrimp': dict['えび'], 'crab': dict['かに'], 'buckwheat': dict['そば'], 'walnut': dict['くるみ'],
    'cashew': dict['カシューナッツ'], 'almond': dict['アーモンド'], 'sesame': dict['ごま']
  };
  const all = { ...dict, ...enDict };
  for (const [name, patterns] of Object.entries(all)) {
    if (key === normalizeText(name)) return uniqueArray([item, ...patterns]);
  }
  return [item];
}

async function enrichRecommendationItemsWithRakuten(result, cfg) {
  if (!cfg || !cfg.rakutenApplicationId || !Array.isArray(result.recommendation_items) || !result.recommendation_items.length) {
    return result;
  }
  const items = [];
  for (const item of result.recommendation_items) {
    if (item.image_url) { items.push(item); continue; }
    try {
      const rakuten = await fetchRakutenFirstItem(item.search_query || item.name, cfg);
      if (rakuten) {
        items.push({
          ...item,
          image_url: rakuten.imageUrl || item.image_url,
          image_source: rakuten.imageUrl ? t().photoSourceRakuten : item.image_source,
          rakuten_item_name: rakuten.itemName || item.rakuten_item_name,
          rakuten_item_url: rakuten.itemUrl || item.rakuten_item_url,
          rakuten_affiliate_url: rakuten.affiliateUrl || item.rakuten_affiliate_url
        });
      } else {
        items.push(item);
      }
    } catch (e) {
      console.warn('Rakuten image fetch failed:', e);
      items.push(item);
    }
  }
  return { ...result, recommendation_items: items };
}

async function fetchRakutenFirstItem(query, cfg) {
  const endpoint = cfg.rakutenApiEndpoint || DEFAULT_CONFIG.rakutenApiEndpoint;
  const url = new URL(endpoint);
  url.searchParams.set('format', 'json');
  url.searchParams.set('keyword', query);
  url.searchParams.set('applicationId', cfg.rakutenApplicationId);
  url.searchParams.set('hits', '1');
  url.searchParams.set('imageFlag', '1');
  if (cfg.rakutenAffiliateId) url.searchParams.set('affiliateId', cfg.rakutenAffiliateId);
  if (cfg.rakutenAccessKey) url.searchParams.set('accessKey', cfg.rakutenAccessKey);
  try {
    const res = await fetch(url.toString());
    if (res.ok) {
      const json = await res.json();
      const parsed = parseRakutenFirstItem(json);
      if (parsed) return parsed;
    }
  } catch (e) {
    console.warn('Rakuten fetch failed, trying JSONP:', e);
  }
  return await fetchRakutenFirstItemJsonp(url);
}

function fetchRakutenFirstItemJsonp(url) {
  return new Promise((resolve) => {
    const callbackName = 'rakutenCb_' + Math.random().toString(36).slice(2);
    const script = document.createElement('script');
    const cleanup = () => {
      try { delete window[callbackName]; } catch (e) { window[callbackName] = undefined; }
      if (script.parentNode) script.parentNode.removeChild(script);
    };
    const timer = setTimeout(() => { cleanup(); resolve(null); }, 8000);
    window[callbackName] = data => {
      clearTimeout(timer);
      const parsed = parseRakutenFirstItem(data);
      cleanup();
      resolve(parsed);
    };
    url.searchParams.set('callback', callbackName);
    script.onerror = () => { clearTimeout(timer); cleanup(); resolve(null); };
    script.src = url.toString();
    document.head.appendChild(script);
  });
}

function parseRakutenFirstItem(json) {
  const first = json?.Items?.[0]?.Item;
  if (!first) return null;
  const medium = first.mediumImageUrls && first.mediumImageUrls[0];
  const small = first.smallImageUrls && first.smallImageUrls[0];
  const imageUrl = typeof medium === 'string' ? medium : (medium?.imageUrl || (typeof small === 'string' ? small : small?.imageUrl) || '');
  return { itemName: first.itemName || '', itemUrl: first.itemUrl || '', affiliateUrl: first.affiliateUrl || '', imageUrl };
}

function renderResult(res, options = {}) {
  const status = getStatusInfo(res.status);
  const cfg = currentConfig || DEFAULT_CONFIG;
  const pending = options.pendingRecommendations;
  updatePreviewResultOverlay(res, { pendingRecommendations: pending });
  document.getElementById('result-area').innerHTML = `
    <div class="alert-box ${status.className}">
      <span style="font-size:64px;">${status.emoji}</span>
      <h2>${status.label}</h2>
      <p><strong>${escapeHtml(res.product_name)}</strong></p>
      <p>${escapeHtml(res.suitability_note || cfg.safetyDisclaimer || t().disclaimer)}</p>
      <div>${res.matches.length ? res.matches.map(m => `<span class="tag tag-danger">${escapeHtml(m)}</span>`).join('') : `<span class="tag tag-success">${escapeHtml(t().noMatches)}</span>`}</div>
      <div class="notice ${res.status === 'danger' ? 'danger-notice' : res.status === 'warning' ? 'warning-notice' : ''}">${escapeHtml(cfg.safetyDisclaimer || t().disclaimer)}</div>
    </div>
    <div class="card"><h3>含有判定</h3><p><strong>Engine:</strong> ${escapeHtml(res.judgement_engine_used || cfg.judgementEngine || 'local')}</p><p><strong>${t().product}:</strong> ${escapeHtml(res.product_name)}</p><p><strong>${t().category}:</strong> ${escapeHtml(res.category)}</p><p><strong>Confidence:</strong> ${escapeHtml(res.confidence)}</p></div>
    ${renderJudgementComparison(res.judgement_comparison)}
    <div class="card"><h3>${t().detected}</h3><div>${res.detected_allergens.length ? res.detected_allergens.map(m => `<span class="tag">${escapeHtml(m)}</span>`).join('') : `<span class="tag">${escapeHtml(t().noMatches)}</span>`}</div><h3 style="margin-top:16px;">${t().warnings}</h3><div>${res.may_contain.length ? res.may_contain.map(m => `<span class="tag tag-warning">${escapeHtml(m)}</span>`).join('') : `<span class="tag">${escapeHtml(t().noMatches)}</span>`}</div></div>
    <details class="card" open><summary style="cursor:pointer;font-weight:800;">${t().ingredients}</summary><div class="mono-box" style="margin-top:10px;">${escapeHtml(res.translated_ingredients || res.ingredients)}</div></details>
    <details class="card"><summary style="cursor:pointer;font-weight:800;">${t().ocr}</summary><div class="mono-box" style="margin-top:10px;">${escapeHtml(res.ocr_text)}</div></details>
    ${pending ? `<div class="card"><h3>${t().recommendations}</h3><div class="notice">含有判定を先に表示しました。関連商品検索を続行中です...</div></div>` : renderRecommendations(res.recommendation_queries, res.category, res.recommendation_items)}
    <details class="card"><summary style="cursor:pointer;font-weight:800;">${t().raw}</summary><pre class="mono-box" style="margin-top:10px;">${escapeHtml(JSON.stringify(res, null, 2))}</pre></details>
  `;
}

function renderJudgementComparison(comparison) {
  if (!comparison) return '';
  const local = comparison.local || {};
  const gemini = comparison.gemini || {};
  return `<div class="card"><h3>精度検証: Local Rules vs Gemini</h3>
    <div class="grid-2">
      <div class="notice"><strong>Local Rules</strong><br>Status: ${escapeHtml(local.status || '')}<br>Matches: ${escapeHtml((local.matches || []).join(', ') || t().noMatches)}</div>
      <div class="notice"><strong>Gemini</strong><br>Status: ${escapeHtml(gemini.status || '')}<br>Matches: ${escapeHtml((gemini.matches || []).join(', ') || t().noMatches)}</div>
    </div>
    <p style="font-size:12px;color:var(--muted);">Status一致: ${comparison.same_status === undefined ? '-' : comparison.same_status ? '一致' : '不一致'} / Matches一致: ${comparison.same_matches === undefined ? '-' : comparison.same_matches ? '一致' : '不一致'}</p>
  </div>`;
}

function renderRecommendationItem(item, category, cfg) {
  const query = item.search_query || item.name || item.image_query;
  const amazonUrl = buildAmazonUrl(query, cfg);
  const rakutenUrl = item.rakuten_affiliate_url || item.rakuten_item_url || buildRakutenUrl(query, cfg);
  const imageSearchUrl = buildImageSearchUrl(item.image_query || query);
  const customLinks = (cfg.customLinks || [])
    .filter(x => x.enabled && x.urlTemplate)
    .map(x => `<a class="link-button custom-link" href="${escapeAttribute(fillTemplate(x.urlTemplate, query, cfg))}" target="_blank" rel="noopener noreferrer sponsored" onclick="trackAffiliateClick('custom','${escapeAttribute(query)}',this.href,'${escapeAttribute(category)}')">${escapeHtml(x.label || t().custom)}</a>`)
    .join('');
  const photoHtml = item.image_url
    ? `<a class="product-photo-link" href="${escapeAttribute(imageSearchUrl)}" target="_blank" rel="noopener noreferrer"><img class="product-photo" src="${escapeAttribute(item.image_url)}" alt="${escapeAttribute(item.name)}" loading="lazy" referrerpolicy="no-referrer" onerror="this.style.display='none';this.parentElement.classList.add('photo-error');"><span class="photo-fallback-label">${escapeHtml(t().imageSearch)}</span></a><small>${escapeHtml(item.image_source || '')}</small>`
    : `<div class="product-photo placeholder"><strong>${escapeHtml(item.name)}</strong><span>${escapeHtml(t().photoUnavailable)}</span><a href="${escapeAttribute(imageSearchUrl)}" target="_blank" rel="noopener noreferrer">${escapeHtml(t().imageSearch)}</a></div><small>楽天Application IDを設定すると写真取得を試行します</small>`;
  return `<div class="recommendation-card product-card">
    <div class="product-image-wrap">${photoHtml}</div>
    <div class="product-detail">
      <h4>${escapeHtml(item.rank ? `${item.rank}. ${item.name}` : item.name)}</h4>
      <p><strong>${escapeHtml(t().searchKeyword)}:</strong> ${escapeHtml(query)}</p>
      ${item.reason ? `<p><strong>${escapeHtml(t().reason)}:</strong> ${escapeHtml(item.reason)}</p>` : ''}
      ${item.allergen_note ? `<p><strong>${escapeHtml(t().allergenNote)}:</strong> ${escapeHtml(item.allergen_note)}</p>` : ''}
      ${item.caution ? `<p><strong>${escapeHtml(t().caution)}:</strong> ${escapeHtml(item.caution)}</p>` : ''}
      <div class="recommendation-actions"><a class="link-button amazon-link" href="${escapeAttribute(amazonUrl)}" target="_blank" rel="noopener noreferrer sponsored" onclick="trackAffiliateClick('amazon','${escapeAttribute(query)}',this.href,'${escapeAttribute(category)}')">${t().amazon}</a><a class="link-button rakuten-link" href="${escapeAttribute(rakutenUrl)}" target="_blank" rel="noopener noreferrer sponsored" onclick="trackAffiliateClick('rakuten','${escapeAttribute(query)}',this.href,'${escapeAttribute(category)}')">${t().rakuten}</a>${customLinks}</div>
    </div>
  </div>`;
}
