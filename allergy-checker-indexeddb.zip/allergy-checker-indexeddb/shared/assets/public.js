const I18N = {
  ja: {
    scan: '🔍 スキャン開始', capture: '📸 判定する', light: '🔦 LIGHT', photo: '📁 PHOTO',
    hold: '動かさないでください...', loading: 'AI分析中...', apiMissing: '管理アプリでGemini API Keyを設定してください。',
    safe: 'OCR上は未検出', critical: '避けたい成分を検出', warning: '注意が必要です', unknown: '判定できません',
    disclaimer: 'この判定は参考情報です。購入・飲食前に必ず商品の原材料表示、アレルギー表示、メーカー公式情報を確認してください。',
    product: '商品名', category: 'カテゴリ', detected: '検出された成分', warnings: '注意表記', ingredients: 'Ingredients List', ocr: 'OCR全文', raw: 'Raw JSON',
    noMatches: '該当なし', recommendations: '代替商品リスト', amazon: 'Amazon検索結果', rakuten: '楽天検索結果', custom: 'リンクを開く',
    productCandidates: '具体的な商品候補', reason: '理由', allergenNote: 'アレルゲン', caution: '注意', photoUnavailable: '商品写真未取得', imageSearch: '画像検索で確認', searchKeyword: '検索キーワード', photoSourceRakuten: '楽天検索結果から取得'
  },
  en: {
    scan: '🔍 START SCAN', capture: '📸 CAPTURE', light: '🔦 LIGHT', photo: '📁 PHOTO',
    hold: 'Hold steady...', loading: 'Analyzing...', apiMissing: 'Set Gemini API Key in the admin app first.',
    safe: 'Not detected in OCR', critical: 'Restricted ingredient detected', warning: 'Caution required', unknown: 'Unable to determine',
    disclaimer: 'This result is for reference only. Always check the product label, allergy information, and official manufacturer information before purchase or consumption.',
    product: 'Product', category: 'Category', detected: 'Detected ingredients', warnings: 'Warnings', ingredients: 'Ingredients List', ocr: 'Full OCR Text', raw: 'Raw JSON',
    noMatches: 'None', recommendations: 'Alternative Product List', amazon: 'Amazon Search Results', rakuten: 'Rakuten Search Results', custom: 'Open Link',
    productCandidates: 'Specific Product Candidates', reason: 'Reason', allergenNote: 'Allergen note', caution: 'Caution', photoUnavailable: 'Product photo unavailable', imageSearch: 'Check with image search', searchKeyword: 'Search keyword', photoSourceRakuten: 'Fetched from Rakuten search results'
  }
};

const COMMON_ALLERGENS_JA = ['小麦','乳','卵','えび','かに','そば','落花生','ピーナッツ','くるみ','カシューナッツ','大豆','ごま','アーモンド','オレンジ','キウイ','牛肉','鶏肉','豚肉','さけ','さば','いか','いくら','バナナ','もも','やまいも','りんご','ゼラチン','グルテン','ナッツ','Vegan'];
const COMMON_ALLERGENS_EN = ['wheat','milk','egg','shrimp','crab','buckwheat','peanut','walnut','cashew','soy','sesame','almond','orange','kiwi','beef','chicken','pork','salmon','mackerel','squid','banana','peach','apple','gelatin','gluten','nuts','vegan'];

let cameraStream = null;
let currentConfig = null;

function userLang() { return localStorage.getItem('ui_lang') || 'ja'; }
function t() { return I18N[userLang()] || I18N.ja; }
function userAllergens() { return toArray(localStorage.getItem('my_diet') || ''); }

async function initPublicApp() {
  await seedInitialDataIfNeeded();
  currentConfig = await getConfig();
  applySiteChrome(currentConfig);
  const scanBtn = document.getElementById('ui-scan-btn');
  if (scanBtn) scanBtn.textContent = t().scan;
  const torchBtn = document.getElementById('ui-torch-btn');
  if (torchBtn) torchBtn.textContent = t().light;
  const photoBtn = document.getElementById('ui-photo-btn');
  if (photoBtn) photoBtn.textContent = t().photo;
  const footer = document.getElementById('safety-disclaimer');
  if (footer) footer.textContent = currentConfig.safetyDisclaimer || t().disclaimer;
  renderAdPlaceholder('main');
}

function applySiteChrome(config) {
  document.querySelectorAll('[data-site-name]').forEach(el => el.textContent = config.siteName || 'Allergy Checker AI');
  document.title = config.siteName || document.title;
}

async function handleScanButton() {
  if (!cameraStream) {
    try {
      cameraStream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment', width: { ideal: 1920 }, height: { ideal: 1080 } }, audio: false });
      document.getElementById('video').srcObject = cameraStream;
      document.getElementById('video').style.display = 'block';
      document.getElementById('file-preview').style.display = 'none';
      document.getElementById('empty-preview').style.display = 'none';
      document.getElementById('scan-line').style.display = 'block';
      document.getElementById('ui-scan-btn').textContent = t().capture;
    } catch (err) {
      alert('Camera Error: ' + err.message);
    }
  } else {
    capture();
  }
}

async function capture() {
  showLoading(t().hold);
  const video = document.getElementById('video');
  const canvas = document.createElement('canvas');
  const MAX_W = 1280;
  let w = video.videoWidth;
  let h = video.videoHeight;
  if (!w || !h) { hideLoading(); alert('Camera Error'); return; }
  if (w > MAX_W) { h *= MAX_W / w; w = MAX_W; }
  canvas.width = Math.round(w);
  canvas.height = Math.round(h);
  canvas.getContext('2d').drawImage(video, 0, 0, canvas.width, canvas.height);
  const dataUrl = canvas.toDataURL('image/jpeg', 0.72);
  const base64 = dataUrl.split(',')[1];
  const preview = document.getElementById('file-preview');
  preview.src = dataUrl;
  preview.style.display = 'block';
  document.getElementById('empty-preview').style.display = 'none';
  stopCamera();
  analyze(base64, 'image/jpeg');
}

function stopCamera() {
  if (cameraStream) {
    cameraStream.getTracks().forEach(track => track.stop());
    cameraStream = null;
  }
  const video = document.getElementById('video');
  if (video) video.style.display = 'none';
  const scanLine = document.getElementById('scan-line');
  if (scanLine) scanLine.style.display = 'none';
  const scanBtn = document.getElementById('ui-scan-btn');
  if (scanBtn) scanBtn.textContent = t().scan;
}

async function toggleTorch() {
  if (!cameraStream) return;
  const track = cameraStream.getVideoTracks()[0];
  const capabilities = track.getCapabilities ? track.getCapabilities() : {};
  const settings = track.getSettings ? track.getSettings() : {};
  if (capabilities.torch) await track.applyConstraints({ advanced: [{ torch: !settings.torch }] });
}

function handleFileSelect(event) {
  const file = event.target.files && event.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = async e => {
    const dataUrl = e.target.result;
    document.getElementById('file-preview').src = dataUrl;
    document.getElementById('file-preview').style.display = 'block';
    document.getElementById('empty-preview').style.display = 'none';
    stopCamera();
    const resized = await resizeImageDataUrl(dataUrl, 1280, 0.72);
    analyze(resized.dataUrl.split(',')[1], resized.mimeType);
  };
  reader.readAsDataURL(file);
}

async function analyze(base64, mimeType) {
  showLoading(t().loading);
  try {
    currentConfig = await getConfig();
    let result;
    if (currentConfig.requestMode === 'mock') {
      result = await analyzeMock();
    } else {
      result = await analyzeGeminiDirect(base64, mimeType, currentConfig);
    }
    result = normalizeAnalysisResult(result);
    result = applyLocalAllergenJudgement(result);
    result = await enrichRecommendationItemsWithRakuten(result, currentConfig);
    renderResult(result);
    const keywords = uniqueArray([...(result.recommendation_queries || []), ...(result.recommendation_items || []).map(item => item.search_query || item.name).filter(Boolean)]);
    for (const q of keywords) {
      await logSearchEvent({ keyword: q, category: result.category, allergens: userAllergens(), source: 'scan' });
    }
  } catch (err) {
    console.error(err);
    alert((err && err.message) || String(err));
  } finally {
    hideLoading();
  }
}

async function analyzeGeminiDirect(base64, mimeType, config) {
  if (!config.geminiApiKey) throw new Error(t().apiMissing);
  const model = config.geminiModel || 'gemini-2.0-flash';
  const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(config.geminiApiKey)}`;
  const systemPrompt = userLang() === 'ja' ? config.systemPromptJa : config.systemPromptEn;
  const body = {
    systemInstruction: { parts: [{ text: systemPrompt }] },
    contents: [{ role: 'user', parts: [{ text: buildUserPrompt() }, { inlineData: { mimeType, data: base64 } }] }],
    generationConfig: { temperature: 0.1, topP: 0.8, topK: 40, responseMimeType: 'application/json' }
  };
  const res = await fetch(endpoint, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
  const json = await res.json();
  if (!res.ok) throw new Error(json?.error?.message || `Gemini API error: ${res.status}`);
  const text = json?.candidates?.[0]?.content?.parts?.map(p => p.text || '').join('\n').trim();
  return parseJsonFromModelText(text);
}

function buildUserPrompt() {
  return `ユーザー言語: ${userLang() === 'ja' ? 'Japanese' : 'English'}\nユーザーが避けたい成分・アレルゲン・食事制限: ${userAllergens().join(', ') || '未設定'}\n\nこの画像の食品表示を読み取り、system promptのJSONスキーマに厳密に従ってJSONのみを返してください。\n安全だと断定せず、OCR結果から判断できる範囲だけを返してください。\n代替商品は具体的な商品名、検索結果リンク用の検索キーワード、商品写真表示用のimage_queryを含むrecommendation_itemsとして返してください。\nAmazonや楽天の個別商品URLは返さず、検索結果に使えるsearch_queryを返してください。`;
}

async function analyzeMock() {
  await new Promise(resolve => setTimeout(resolve, 700));
  const restricted = userAllergens();
  const restrictedText = restricted.join(', ');
  const hasGelatinApple = /ゼラチン|りんご|gelatin|apple/i.test(restrictedText);
  if (hasGelatinApple || userLang() === 'ja') {
    return {
      status: 'danger',
      product_name: userLang() === 'ja' ? 'サンプル グミ' : 'Sample Gummy Candy',
      category: userLang() === 'ja' ? 'グミ・キャンディ' : 'Gummy / Candy',
      ocr_text: userLang() === 'ja' ? '名称: グミキャンディ\n原材料名: 水あめ、砂糖、ゼラチン、濃縮りんご果汁、酸味料、香料\n一部にりんご・ゼラチンを含む' : 'Name: Gummy candy\nIngredients: starch syrup, sugar, gelatin, concentrated apple juice, acidulant, flavoring. Contains apple and gelatin.',
      ingredients: userLang() === 'ja' ? '水あめ、砂糖、ゼラチン、濃縮りんご果汁、酸味料、香料' : 'starch syrup, sugar, gelatin, concentrated apple juice, acidulant, flavoring',
      allergy_label: userLang() === 'ja' ? '一部にりんご・ゼラチンを含む' : 'Contains apple and gelatin',
      translated_ingredients: userLang() === 'ja' ? '水あめ、砂糖、ゼラチン、濃縮りんご果汁、酸味料、香料' : 'Starch syrup, sugar, gelatin, concentrated apple juice, acidulant, flavoring',
      detected_allergens: userLang() === 'ja' ? ['ゼラチン', 'りんご'] : ['gelatin', 'apple'],
      matches: userLang() === 'ja' ? ['ゼラチン', 'りんご'] : ['gelatin', 'apple'],
      may_contain: [],
      recommendation_queries: userLang() === 'ja' ? ['ボンタンアメ', '兵六餅', 'ビオクラ 有機グミ コーラ', '杉本屋 厚切り寒天'] : ['Bontan Ame', 'Hyoroku Mochi', 'Biokura Organic Gummy Cola', 'Sugimotoya Thick-Cut Kanten'],
      recommendation_items: userLang() === 'ja' ? [
        { rank: 1, name: 'セイカ食品 ボンタンアメ', search_query: 'ボンタンアメ', image_query: 'セイカ食品 ボンタンアメ', image_url: '', reason: 'もち米を主原料としたもちもちした菓子で、グミの代替として探しやすい候補です。', allergen_note: 'ゼラチン・りんご不使用の候補として確認対象です。大豆など他アレルゲンは要確認です。', caution: '購入前に最新の原材料表示とメーカー公式情報を確認してください。' },
        { rank: 2, name: 'セイカ食品 兵六餅', search_query: '兵六餅', image_query: 'セイカ食品 兵六餅', image_url: '', reason: 'ボンタンアメの姉妹品で、もちもちした食感の代替候補です。', allergen_note: 'ゼラチン・りんご不使用の候補として確認対象です。大豆など他アレルゲンは要確認です。', caution: '海苔や抹茶風味があるため、原材料とアレルギー表示を確認してください。' },
        { rank: 3, name: 'ビオクラ 有機グミ コーラ味', search_query: 'ビオクラ 有機グミ コーラ', image_query: 'ビオクラ 有機グミ コーラ味', image_url: '', reason: 'ゼラチンの代わりに植物由来原料を使うヴィーガングミ系の候補です。', allergen_note: 'フルーツ味はりんごを含む可能性があるため、コーラ味を優先して確認してください。', caution: '味違いで原材料が変わるため、必ずコーラ味の表示を確認してください。' },
        { rank: 4, name: '杉本屋製菓 厚切り寒天', search_query: '杉本屋 厚切り寒天', image_query: '杉本屋製菓 厚切り寒天', image_url: '', reason: 'ゼラチンではなく寒天を使った菓子で、ゼリーとグミの中間の食感の候補です。', allergen_note: 'ミックス味は避け、ぶどう味やコーラ味などを選んで原材料を確認してください。', caution: '味によって果汁や香料が異なるため、りんご由来成分がないか確認してください。' }
      ] : [
        { rank: 1, name: 'Seika Foods Bontan Ame', search_query: 'Bontan Ame', image_query: 'Seika Foods Bontan Ame', image_url: '', reason: 'A chewy rice-based candy candidate that can be searched as an alternative to gummies.', allergen_note: 'Candidate to check for gelatin-free and apple-free needs. Verify soy and other allergens.', caution: 'Always verify the latest ingredient label and official manufacturer information.' },
        { rank: 2, name: 'Seika Foods Hyoroku Mochi', search_query: 'Hyoroku Mochi', image_query: 'Seika Foods Hyoroku Mochi', image_url: '', reason: 'A related chewy candy candidate.', allergen_note: 'Candidate to check for gelatin-free and apple-free needs.', caution: 'Check ingredients and allergy label before purchase.' },
        { rank: 3, name: 'Biokura Organic Gummy Cola Flavor', search_query: 'Biokura Organic Gummy Cola', image_query: 'Biokura Organic Gummy Cola Flavor', image_url: '', reason: 'A vegan-style gummy candidate using plant-derived gelling agents.', allergen_note: 'Fruit flavors may contain apple, so prioritize cola flavor and verify.', caution: 'Ingredients differ by flavor. Verify cola flavor specifically.' },
        { rank: 4, name: 'Sugimotoya Thick-Cut Kanten', search_query: 'Sugimotoya Thick-Cut Kanten', image_query: 'Sugimotoya Thick-Cut Kanten', image_url: '', reason: 'A kanten-based snack candidate with jelly-like texture.', allergen_note: 'Choose non-mixed flavors and verify no apple-derived ingredients.', caution: 'Ingredients vary by flavor. Check label before purchase.' }
      ],
      suitability_note: userLang() === 'ja' ? 'OCR結果ではゼラチンとりんごが検出されました。代替候補は検索用の参考情報です。購入・飲食前に必ず表示を確認してください。' : 'The OCR result detected gelatin and apple. Alternative candidates are reference search suggestions only. Always verify labels before purchase or consumption.',
      confidence: 'high',
      notes: userLang() === 'ja' ? ['検索結果リンクは個別商品の安全性を保証しません。', '写真は設定された楽天APIまたは返却されたimage_urlから表示します。'] : ['Search result links do not guarantee product safety.', 'Photos are displayed from configured Rakuten API or returned image_url.']
    };
  }

  const hasWheat = restricted.some(v => /小麦|wheat|gluten/i.test(v));
  return {
    status: hasWheat ? 'danger' : 'warning',
    product_name: userLang() === 'ja' ? 'サンプル クッキー' : 'Sample Cookies',
    category: userLang() === 'ja' ? 'クッキー' : 'Cookies',
    ocr_text: userLang() === 'ja' ? '名称: クッキー\n原材料名: 小麦粉、砂糖、植物油脂、卵、食塩 / 膨張剤、香料\n一部に小麦・卵を含む\n本品製造工場では乳成分を含む製品を製造しています。' : 'Name: Cookies\nIngredients: wheat flour, sugar, vegetable oil, egg, salt, baking powder, flavoring. Contains wheat and egg. Manufactured in a facility that also processes milk.',
    ingredients: userLang() === 'ja' ? '小麦粉、砂糖、植物油脂、卵、食塩 / 膨張剤、香料' : 'wheat flour, sugar, vegetable oil, egg, salt, baking powder, flavoring',
    allergy_label: userLang() === 'ja' ? '一部に小麦・卵を含む。本品製造工場では乳成分を含む製品を製造しています。' : 'Contains wheat and egg. Manufactured in a facility that also processes milk.',
    translated_ingredients: userLang() === 'ja' ? '小麦粉、砂糖、植物油脂、卵、食塩、膨張剤、香料' : 'Wheat flour, sugar, vegetable oil, egg, salt, baking powder, flavoring',
    detected_allergens: userLang() === 'ja' ? ['小麦', '卵', '乳成分の製造ライン注意'] : ['wheat', 'egg', 'milk facility warning'],
    matches: hasWheat ? (userLang() === 'ja' ? ['小麦'] : ['wheat']) : [],
    may_contain: userLang() === 'ja' ? ['乳成分を含む製品を同じ工場で製造'] : ['Manufactured in a facility that also processes milk'],
    recommendation_queries: userLang() === 'ja' ? ['小麦不使用 クッキー', 'グルテンフリー クッキー', '米粉 クッキー アレルギー対応'] : ['wheat free cookies', 'gluten free cookies', 'allergy friendly rice flour cookies'],
    recommendation_items: [],
    suitability_note: userLang() === 'ja' ? 'OCR結果では小麦と卵が検出され、乳成分に関する製造ライン注意もあります。購入・飲食前に必ず表示を確認してください。' : 'The OCR result detected wheat and egg, with a milk facility warning. Always verify the product label before purchase or consumption.',
    confidence: 'high', notes: []
  };
}

function normalizeAnalysisResult(data) {
  const raw = data && typeof data === 'object' ? data : {};
  let status = raw.status || 'unknown';
  if (status === 'safe') status = 'clear';
  if (!['danger', 'warning', 'clear', 'unknown'].includes(status)) status = 'unknown';
  return {
    status,
    product_name: raw.product_name || raw.productName || '不明',
    category: raw.category || '不明',
    ocr_text: raw.ocr_text || raw.ocrText || '',
    ingredients: raw.ingredients || '',
    allergy_label: raw.allergy_label || raw.allergyLabel || '',
    translated_ingredients: raw.translated_ingredients || raw.translatedIngredients || raw.ingredients || '',
    detected_allergens: toArray(raw.detected_allergens || raw.detectedAllergens),
    matches: toArray(raw.matches),
    may_contain: toArray(raw.may_contain || raw.mayContain),
    recommendation_queries: toArray(raw.recommendation_queries || raw.recommendationQueries),
    recommendation_items: normalizeRecommendationItems(raw.recommendation_items || raw.recommendationItems),
    suitability_note: raw.suitability_note || raw.suitabilityNote || '',
    confidence: raw.confidence || 'low',
    notes: toArray(raw.notes)
  };
}

function normalizeRecommendationItems(value) {
  if (!value) return [];
  const arr = Array.isArray(value) ? value : [value];
  return arr.map((item, index) => {
    if (typeof item === 'string') {
      return { rank: index + 1, name: item, search_query: item, image_query: item, image_url: '', reason: '', allergen_note: '', caution: '' };
    }
    const obj = item && typeof item === 'object' ? item : {};
    const name = obj.name || obj.product_name || obj.productName || obj.search_query || obj.searchQuery || '';
    const searchQuery = obj.search_query || obj.searchQuery || name;
    return {
      rank: Number(obj.rank || index + 1),
      name,
      search_query: searchQuery,
      image_query: obj.image_query || obj.imageQuery || searchQuery || name,
      image_url: obj.image_url || obj.imageUrl || '',
      image_source: obj.image_source || obj.imageSource || '',
      reason: obj.reason || obj.description || '',
      allergen_note: obj.allergen_note || obj.allergenNote || '',
      caution: obj.caution || obj.warning || '',
      rakuten_item_name: obj.rakuten_item_name || obj.rakutenItemName || '',
      rakuten_item_url: obj.rakuten_item_url || obj.rakutenItemUrl || '',
      rakuten_affiliate_url: obj.rakuten_affiliate_url || obj.rakutenAffiliateUrl || ''
    };
  }).filter(item => item.name || item.search_query);
}

function applyLocalAllergenJudgement(res) {
  const restricted = userAllergens();
  const allText = [res.ocr_text, res.ingredients, res.allergy_label, res.translated_ingredients, ...(res.detected_allergens || []), ...(res.matches || [])].join('\n');
  const localMatches = restricted.filter(item => normalizeText(allText).includes(normalizeText(item)));
  const mayContainPatterns = userLang() === 'ja' ? ['同一工場','製造ライン','含む可能性','コンタミ','本品製造工場','共通の設備','同じ設備'] : ['may contain','facility','same line','shared equipment','processed in','manufactured in a facility'];
  const localMay = mayContainPatterns.filter(p => normalizeText(allText).includes(normalizeText(p)));
  const matches = uniqueArray([...(res.matches || []), ...localMatches]);
  const may_contain = uniqueArray([...(res.may_contain || []), ...localMay]);
  let status = res.status;
  if (matches.length > 0) status = 'danger';
  else if (may_contain.length > 0 && status !== 'danger') status = 'warning';
  else if (!res.ocr_text && !res.ingredients && !res.allergy_label) status = 'unknown';
  else if (!['danger', 'warning', 'unknown'].includes(status)) status = 'clear';
  const recommendation_queries = ensureRecommendationQueries(res.recommendation_queries, res.category, restricted, res.recommendation_items);
  const recommendation_items = ensureRecommendationItems(res.recommendation_items, recommendation_queries);
  return { ...res, status, matches, may_contain, recommendation_queries, recommendation_items };
}

function ensureRecommendationQueries(existing, category, restricted, items = []) {
  const arr = uniqueArray([...toArray(existing), ...toArray(items.map(item => item.search_query || item.name))]);
  if (arr.length) return arr.slice(0, 12);
  const cat = category && category !== '不明' ? category : (userLang() === 'ja' ? '食品' : 'food');
  const base = restricted.length ? restricted : (userLang() === 'ja' ? ['アレルギー対応'] : ['allergy friendly']);
  return uniqueArray(base.slice(0, 4).map(x => userLang() === 'ja' ? `${x} 不使用 ${cat}` : `${x} free ${cat}`)).slice(0, 8);
}

function ensureRecommendationItems(existing, queries) {
  const items = normalizeRecommendationItems(existing);
  if (items.length) return items.slice(0, 12);
  return toArray(queries).slice(0, 8).map((query, index) => ({
    rank: index + 1,
    name: query,
    search_query: query,
    image_query: query,
    image_url: '',
    image_source: '',
    reason: userLang() === 'ja' ? '代替商品を探すための検索候補です。' : 'Search candidate for alternative products.',
    allergen_note: userLang() === 'ja' ? '不使用を保証するものではありません。' : 'This does not guarantee allergen-free status.',
    caution: userLang() === 'ja' ? '購入前に原材料表示、アレルギー表示、メーカー公式情報を確認してください。' : 'Verify ingredients, allergy label, and manufacturer information before purchase.'
  }));
}

async function enrichRecommendationItemsWithRakuten(result, cfg) {
  if (!cfg || !cfg.rakutenApplicationId || !Array.isArray(result.recommendation_items) || !result.recommendation_items.length) {
    return result;
  }
  const items = [];
  for (const item of result.recommendation_items) {
    if (item.image_url) { items.push(item); continue; }
    try {
      const rakuten = await fetchRakutenFirstItem(item.search_query || item.name, cfg);
      if (rakuten) {
        items.push({
          ...item,
          image_url: rakuten.imageUrl || item.image_url,
          image_source: rakuten.imageUrl ? t().photoSourceRakuten : item.image_source,
          rakuten_item_name: rakuten.itemName || item.rakuten_item_name,
          rakuten_item_url: rakuten.itemUrl || item.rakuten_item_url,
          rakuten_affiliate_url: rakuten.affiliateUrl || item.rakuten_affiliate_url
        });
      } else {
        items.push(item);
      }
    } catch (e) {
      console.warn('Rakuten image fetch failed:', e);
      items.push(item);
    }
  }
  return { ...result, recommendation_items: items };
}

async function fetchRakutenFirstItem(query, cfg) {
  const endpoint = cfg.rakutenApiEndpoint || DEFAULT_CONFIG.rakutenApiEndpoint;
  const url = new URL(endpoint);
  url.searchParams.set('format', 'json');
  url.searchParams.set('keyword', query);
  url.searchParams.set('applicationId', cfg.rakutenApplicationId);
  url.searchParams.set('hits', '1');
  url.searchParams.set('imageFlag', '1');
  if (cfg.rakutenAffiliateId) url.searchParams.set('affiliateId', cfg.rakutenAffiliateId);
  if (cfg.rakutenAccessKey) url.searchParams.set('accessKey', cfg.rakutenAccessKey);
  const res = await fetch(url.toString());
  if (!res.ok) return null;
  const json = await res.json();
  const first = json?.Items?.[0]?.Item;
  if (!first) return null;
  const medium = first.mediumImageUrls && first.mediumImageUrls[0];
  const small = first.smallImageUrls && first.smallImageUrls[0];
  const imageUrl = typeof medium === 'string' ? medium : (medium?.imageUrl || (typeof small === 'string' ? small : small?.imageUrl) || '');
  return { itemName: first.itemName || '', itemUrl: first.itemUrl || '', affiliateUrl: first.affiliateUrl || '', imageUrl };
}

function renderResult(res) {
  const status = getStatusInfo(res.status);
  const cfg = currentConfig || DEFAULT_CONFIG;
  document.getElementById('result-area').innerHTML = `
    <div class="alert-box ${status.className}">
      <span style="font-size:64px;">${status.emoji}</span>
      <h2>${status.label}</h2>
      <p><strong>${escapeHtml(res.product_name)}</strong></p>
      <p>${escapeHtml(res.suitability_note || cfg.safetyDisclaimer || t().disclaimer)}</p>
      <div>${res.matches.length ? res.matches.map(m => `<span class="tag tag-danger">${escapeHtml(m)}</span>`).join('') : `<span class="tag tag-success">${escapeHtml(t().noMatches)}</span>`}</div>
      <div class="notice ${res.status === 'danger' ? 'danger-notice' : res.status === 'warning' ? 'warning-notice' : ''}">${escapeHtml(cfg.safetyDisclaimer || t().disclaimer)}</div>
    </div>
    <div class="card"><h3>判定結果</h3><p><strong>${t().product}:</strong> ${escapeHtml(res.product_name)}</p><p><strong>${t().category}:</strong> ${escapeHtml(res.category)}</p><p><strong>Confidence:</strong> ${escapeHtml(res.confidence)}</p></div>
    <div class="card"><h3>${t().detected}</h3><div>${res.detected_allergens.length ? res.detected_allergens.map(m => `<span class="tag">${escapeHtml(m)}</span>`).join('') : `<span class="tag">${escapeHtml(t().noMatches)}</span>`}</div><h3 style="margin-top:16px;">${t().warnings}</h3><div>${res.may_contain.length ? res.may_contain.map(m => `<span class="tag tag-warning">${escapeHtml(m)}</span>`).join('') : `<span class="tag">${escapeHtml(t().noMatches)}</span>`}</div></div>
    <details class="card" open><summary style="cursor:pointer;font-weight:800;">${t().ingredients}</summary><div class="mono-box" style="margin-top:10px;">${escapeHtml(res.translated_ingredients || res.ingredients)}</div></details>
    <details class="card"><summary style="cursor:pointer;font-weight:800;">${t().ocr}</summary><div class="mono-box" style="margin-top:10px;">${escapeHtml(res.ocr_text)}</div></details>
    ${renderRecommendations(res.recommendation_queries, res.category, res.recommendation_items)}
    <details class="card"><summary style="cursor:pointer;font-weight:800;">${t().raw}</summary><pre class="mono-box" style="margin-top:10px;">${escapeHtml(JSON.stringify(res, null, 2))}</pre></details>
  `;
}

function getStatusInfo(status) {
  if (status === 'danger') return { label: t().critical, emoji: '😫', className: 'alert-critical' };
  if (status === 'warning') return { label: t().warning, emoji: '⚠️', className: 'alert-warning' };
  if (status === 'clear') return { label: t().safe, emoji: '😊', className: 'alert-safe' };
  return { label: t().unknown, emoji: '❓', className: 'alert-unknown' };
}

function renderRecommendations(queries, category, items = []) {
  const cfg = currentConfig || DEFAULT_CONFIG;
  const productItems = ensureRecommendationItems(items, queries);
  if (!productItems.length) return '';
  return `<div class="recommendations"><h3>${t().recommendations}</h3>${productItems.map(item => renderRecommendationItem(item, category, cfg)).join('')}</div>`;
}

function renderRecommendationItem(item, category, cfg) {
  const query = item.search_query || item.name || item.image_query;
  const amazonUrl = buildAmazonUrl(query, cfg);
  const rakutenUrl = buildRakutenUrl(query, cfg);
  const imageSearchUrl = buildImageSearchUrl(item.image_query || query);
  const customLinks = (cfg.customLinks || [])
    .filter(x => x.enabled && x.urlTemplate)
    .map(x => `<a class="link-button custom-link" href="${escapeAttribute(fillTemplate(x.urlTemplate, query, cfg))}" target="_blank" rel="noopener noreferrer sponsored" onclick="trackAffiliateClick('custom','${escapeAttribute(query)}',this.href,'${escapeAttribute(category)}')">${escapeHtml(x.label || t().custom)}</a>`)
    .join('');
  const photoHtml = item.image_url
    ? `<img class="product-photo" src="${escapeAttribute(item.image_url)}" alt="${escapeAttribute(item.name)}" loading="lazy" referrerpolicy="no-referrer"><small>${escapeHtml(item.image_source || '')}</small>`
    : `<div class="product-photo placeholder"><span>${escapeHtml(t().photoUnavailable)}</span><a href="${escapeAttribute(imageSearchUrl)}" target="_blank" rel="noopener noreferrer">${escapeHtml(t().imageSearch)}</a></div>`;
  return `<div class="recommendation-card product-card">
    <div class="product-image-wrap">${photoHtml}</div>
    <div class="product-detail">
      <h4>${escapeHtml(item.rank ? `${item.rank}. ${item.name}` : item.name)}</h4>
      <p><strong>${escapeHtml(t().searchKeyword)}:</strong> ${escapeHtml(query)}</p>
      ${item.reason ? `<p><strong>${escapeHtml(t().reason)}:</strong> ${escapeHtml(item.reason)}</p>` : ''}
      ${item.allergen_note ? `<p><strong>${escapeHtml(t().allergenNote)}:</strong> ${escapeHtml(item.allergen_note)}</p>` : ''}
      ${item.caution ? `<p><strong>${escapeHtml(t().caution)}:</strong> ${escapeHtml(item.caution)}</p>` : ''}
      <div class="recommendation-actions"><a class="link-button amazon-link" href="${escapeAttribute(amazonUrl)}" target="_blank" rel="noopener noreferrer sponsored" onclick="trackAffiliateClick('amazon','${escapeAttribute(query)}',this.href,'${escapeAttribute(category)}')">${t().amazon}</a><a class="link-button rakuten-link" href="${escapeAttribute(rakutenUrl)}" target="_blank" rel="noopener noreferrer sponsored" onclick="trackAffiliateClick('rakuten','${escapeAttribute(query)}',this.href,'${escapeAttribute(category)}')">${t().rakuten}</a>${customLinks}</div>
    </div>
  </div>`;
}

function buildAmazonUrl(query, cfg) { return fillTemplate(cfg.amazonSearchTemplate || DEFAULT_CONFIG.amazonSearchTemplate, query, cfg); }
function buildRakutenUrl(query, cfg) { return fillTemplate(cfg.rakutenSearchTemplate || DEFAULT_CONFIG.rakutenSearchTemplate, query, cfg); }
function buildImageSearchUrl(query) { return `https://www.google.com/search?tbm=isch&q=${encodeURIComponent(query)}`; }
function fillTemplate(template, query, cfg) {
  const domain = String(cfg.amazonDomain || 'amazon.co.jp').replace(/^https?:\/\//, '').replace(/^www\./, '').replace(/\/.*$/, '');
  return String(template)
    .replaceAll('{query}', encodeURIComponent(query))
    .replaceAll('{queryRaw}', query)
    .replaceAll('{domain}', domain)
    .replaceAll('{tag}', encodeURIComponent(cfg.amazonAssociateTag || ''))
    .replaceAll('{rakutenAffiliateId}', encodeURIComponent(cfg.rakutenAffiliateId || ''));
}

async function trackAffiliateClick(provider, keyword, url, category) {
  try { await logAffiliateClick({ provider, keyword, url, category, allergens: userAllergens() }); } catch (e) { console.warn(e); }
}
window.trackAffiliateClick = trackAffiliateClick;

function showLoading(text) { const el = document.getElementById('loading-overlay'); if (el) { el.style.display = 'flex'; document.getElementById('ui-loading-text').textContent = text || ''; } }
function hideLoading() { const el = document.getElementById('loading-overlay'); if (el) el.style.display = 'none'; }

function resizeImageDataUrl(dataUrl, maxWidth, quality) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => {
      let w = img.width; let h = img.height;
      if (w > maxWidth) { h *= maxWidth / w; w = maxWidth; }
      const canvas = document.createElement('canvas');
      canvas.width = Math.round(w); canvas.height = Math.round(h);
      canvas.getContext('2d').drawImage(img, 0, 0, canvas.width, canvas.height);
      resolve({ dataUrl: canvas.toDataURL('image/jpeg', quality), mimeType: 'image/jpeg' });
    };
    img.onerror = reject;
    img.src = dataUrl;
  });
}

function parseJsonFromModelText(text) {
  const cleaned = String(text || '').replace(/^```json\s*/i, '').replace(/^```\s*/i, '').replace(/```$/i, '').trim();
  try { return JSON.parse(cleaned); } catch (e) {
    const match = cleaned.match(/\{[\s\S]*\}/);
    if (match) return JSON.parse(match[0]);
    throw e;
  }
}

function renderAdPlaceholder(slot) {
  const container = document.querySelector(`[data-ad-slot="${slot}"]`);
  if (!container) return;
  getConfig().then(cfg => {
    if (cfg.adsenseEnabled && cfg.adsensePublisherId) {
      container.innerHTML = `<div class="ad-placeholder">AdSense広告枠: ${escapeHtml(slot)}<br>Publisher: ${escapeHtml(cfg.adsensePublisherId)}</div>`;
    } else {
      container.innerHTML = `<div class="ad-placeholder">広告枠 / Ad Placeholder</div>`;
    }
  });
}
