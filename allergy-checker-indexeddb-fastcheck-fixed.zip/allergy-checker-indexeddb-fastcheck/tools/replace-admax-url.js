#!/usr/bin/env node
const fs = require('fs');
const path = require('path');

const nextUrl = process.argv[2];
if (!nextUrl || !/^https?:\/\/adm\.shinobi\.jp\/s\/[A-Za-z0-9_-]+$/.test(nextUrl)) {
  console.error('Usage: node tools/replace-admax-url.js https://adm.shinobi.jp/s/xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
  process.exit(1);
}

const root = path.resolve(__dirname, '..');
const targets = [
  'public-app/index.html',
  'public-app/blog.html',
  'public-app/article.html',
  'public-app/rankings.html',
  'shared/assets/db.js',
];

for (const rel of targets) {
  const file = path.join(root, rel);
  let text = fs.readFileSync(file, 'utf8');
  const before = text;
  text = text.replace(/https:\/\/adm\.shinobi\.jp\/s\/[A-Za-z0-9_-]+/g, nextUrl);
  if (text !== before) {
    fs.writeFileSync(file, text, 'utf8');
    console.log('updated:', rel);
  } else {
    console.log('no match:', rel);
  }
}
