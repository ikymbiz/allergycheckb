async function initAdminShell(active) {
  await seedInitialDataIfNeeded();
  const config = await getConfig();
  document.querySelectorAll('[data-site-name]').forEach(el => el.textContent = config.siteName || 'Allergy Checker AI');
  const nav = document.getElementById('admin-nav');
  if (nav) {
    const items = [
      ['index.html', 'Dashboard', 'dashboard'],
      ['config.html', 'Config', 'config'],
      ['prompts.html', 'Prompts', 'prompts'],
      ['articles.html', 'Articles', 'articles'],
      ['rankings.html', 'Rankings', 'rankings'],
      ['ads.html', 'Ads / Affiliate', 'ads']
    ];
    nav.innerHTML = items.map(([href, label, key]) => `<a class="${active === key ? 'active' : ''}" href="${href}">${label}</a>`).join('') + `<a href="../index.html">Public</a>`;
  }
}

async function initAdminDashboard() {
  await initAdminShell('dashboard');
  const [config, articles, rankings, searches, clicks] = await Promise.all([
    getConfig(), listArticles(), listRankings(10), listEvents('searchEvents', 10), listEvents('affiliateClicks', 10)
  ]);
  document.getElementById('dashboard').innerHTML = `
    <div class="grid-3">
      <div class="card"><h3>Articles</h3><p style="font-size:32px;font-weight:900;">${articles.length}</p></div>
      <div class="card"><h3>Rankings</h3><p style="font-size:32px;font-weight:900;">${rankings.length}</p></div>
      <div class="card"><h3>Mode</h3><p style="font-size:24px;font-weight:900;">${escapeHtml(config.requestMode)}</p></div>
    </div>
    <div class="card"><h3>現在の状態</h3><div class="notice warning-notice">現在はサーバーなし、IndexedDB保存の構成です。Gemini API KeyなどはこのブラウザのIndexedDBに保存されます。公開運用では秘密情報をサーバー側へ移してください。</div></div>
    <div class="grid-2">
      <div class="card"><h3>最近の検索イベント</h3>${renderEventTable(searches, ['keyword','category','createdAt'])}</div>
      <div class="card"><h3>最近のクリック</h3>${renderEventTable(clicks, ['provider','keyword','createdAt'])}</div>
    </div>
  `;
}

async function initAdminConfig() {
  await initAdminShell('config');
  const cfg = await getConfig();
  document.getElementById('siteName').value = cfg.siteName || '';
  document.getElementById('siteUrl').value = cfg.siteUrl || '';
  document.getElementById('contactEmail').value = cfg.contactEmail || '';
  document.getElementById('geminiApiKey').value = cfg.geminiApiKey || '';
  document.getElementById('geminiModel').value = cfg.geminiModel || 'gemini-2.0-flash';
  document.getElementById('requestMode').value = cfg.requestMode || 'mock';
  document.getElementById('safetyDisclaimer').value = cfg.safetyDisclaimer || DEFAULT_CONFIG.safetyDisclaimer;
  document.getElementById('affiliateDisclosure').value = cfg.affiliateDisclosure || DEFAULT_CONFIG.affiliateDisclosure;
}

async function saveAdminConfig() {
  const current = await getConfig();
  await saveConfig({
    ...current,
    siteName: document.getElementById('siteName').value,
    siteUrl: document.getElementById('siteUrl').value,
    contactEmail: document.getElementById('contactEmail').value,
    geminiApiKey: document.getElementById('geminiApiKey').value,
    geminiModel: document.getElementById('geminiModel').value,
    requestMode: document.getElementById('requestMode').value,
    safetyDisclaimer: document.getElementById('safetyDisclaimer').value,
    affiliateDisclosure: document.getElementById('affiliateDisclosure').value
  });
  alert('保存しました');
}

async function initAdminPrompts() {
  await initAdminShell('prompts');
  const cfg = await getConfig();
  document.getElementById('systemPromptJa').value = cfg.systemPromptJa || DEFAULT_SYSTEM_PROMPT_JA;
  document.getElementById('systemPromptEn').value = cfg.systemPromptEn || DEFAULT_SYSTEM_PROMPT_EN;
}

async function savePrompts() {
  const current = await getConfig();
  await saveConfig({ ...current, systemPromptJa: document.getElementById('systemPromptJa').value, systemPromptEn: document.getElementById('systemPromptEn').value });
  alert('保存しました');
}

async function resetPrompts() {
  document.getElementById('systemPromptJa').value = DEFAULT_SYSTEM_PROMPT_JA;
  document.getElementById('systemPromptEn').value = DEFAULT_SYSTEM_PROMPT_EN;
  await savePrompts();
}

async function initAdminAds() {
  await initAdminShell('ads');
  const cfg = await getConfig();
  document.getElementById('amazonAssociateTag').value = cfg.amazonAssociateTag || '';
  document.getElementById('amazonDomain').value = cfg.amazonDomain || 'amazon.co.jp';
  document.getElementById('amazonSearchTemplate').value = cfg.amazonSearchTemplate || DEFAULT_CONFIG.amazonSearchTemplate;
  document.getElementById('rakutenAffiliateId').value = cfg.rakutenAffiliateId || '';
  document.getElementById('rakutenApplicationId').value = cfg.rakutenApplicationId || '';
  document.getElementById('rakutenAccessKey').value = cfg.rakutenAccessKey || '';
  document.getElementById('rakutenApiEndpoint').value = cfg.rakutenApiEndpoint || DEFAULT_CONFIG.rakutenApiEndpoint;
  document.getElementById('rakutenSearchTemplate').value = cfg.rakutenSearchTemplate || DEFAULT_CONFIG.rakutenSearchTemplate;
  document.getElementById('adsenseEnabled').checked = !!cfg.adsenseEnabled;
  document.getElementById('adsensePublisherId').value = cfg.adsensePublisherId || '';
  document.getElementById('adSlotMain').value = cfg.adSlotMain || '';
  document.getElementById('adSlotArticle').value = cfg.adSlotArticle || '';
  document.getElementById('adSlotRanking').value = cfg.adSlotRanking || '';
  document.getElementById('customLinks').value = JSON.stringify(cfg.customLinks || DEFAULT_CONFIG.customLinks, null, 2);
}

async function saveAdsConfig() {
  const current = await getConfig();
  let customLinks = [];
  try { customLinks = JSON.parse(document.getElementById('customLinks').value || '[]'); } catch (e) { alert('Custom Links JSONが不正です'); return; }
  await saveConfig({
    ...current,
    amazonAssociateTag: document.getElementById('amazonAssociateTag').value,
    amazonDomain: document.getElementById('amazonDomain').value,
    amazonSearchTemplate: document.getElementById('amazonSearchTemplate').value,
    rakutenAffiliateId: document.getElementById('rakutenAffiliateId').value,
    rakutenApplicationId: document.getElementById('rakutenApplicationId').value,
    rakutenAccessKey: document.getElementById('rakutenAccessKey').value,
    rakutenApiEndpoint: document.getElementById('rakutenApiEndpoint').value,
    rakutenSearchTemplate: document.getElementById('rakutenSearchTemplate').value,
    adsenseEnabled: document.getElementById('adsenseEnabled').checked,
    adsensePublisherId: document.getElementById('adsensePublisherId').value,
    adSlotMain: document.getElementById('adSlotMain').value,
    adSlotArticle: document.getElementById('adSlotArticle').value,
    adSlotRanking: document.getElementById('adSlotRanking').value,
    customLinks
  });
  alert('保存しました');
}

async function initAdminArticles() {
  await initAdminShell('articles');
  await refreshArticleList();
  clearArticleForm();
}

async function refreshArticleList() {
  const rows = await listArticles();
  document.getElementById('article-list-admin').innerHTML = rows.length ? `
    <div class="table-wrap"><table><thead><tr><th>Title</th><th>Slug</th><th>Status</th><th>Views</th><th>Action</th></tr></thead><tbody>
    ${rows.map(a => `<tr><td>${escapeHtml(a.title)}</td><td>${escapeHtml(a.slug)}</td><td>${escapeHtml(a.status)}</td><td>${Number(a.viewCount || 0)}</td><td><button class="btn-soft" onclick="loadArticleIntoForm('${escapeAttribute(a.id)}')">Edit</button> <button class="btn-danger" onclick="removeArticle('${escapeAttribute(a.id)}')">Delete</button></td></tr>`).join('')}
    </tbody></table></div>` : '<div class="notice">記事がありません。</div>';
}

function clearArticleForm() {
  document.getElementById('articleId').value = '';
  document.getElementById('title').value = '';
  document.getElementById('slug').value = '';
  document.getElementById('excerpt').value = '';
  document.getElementById('category').value = '';
  document.getElementById('tags').value = '';
  document.getElementById('status').value = 'draft';
  document.getElementById('body').value = '';
}

async function loadArticleIntoForm(id) {
  const a = await getArticleById(id);
  if (!a) return;
  document.getElementById('articleId').value = a.id;
  document.getElementById('title').value = a.title || '';
  document.getElementById('slug').value = a.slug || '';
  document.getElementById('excerpt').value = a.excerpt || '';
  document.getElementById('category').value = a.category || '';
  document.getElementById('tags').value = (a.tags || []).join(', ');
  document.getElementById('status').value = a.status || 'draft';
  document.getElementById('body').value = a.body || '';
  scrollTo({ top: 0, behavior: 'smooth' });
}

async function saveArticleFromForm() {
  await saveArticle({
    id: document.getElementById('articleId').value || undefined,
    title: document.getElementById('title').value,
    slug: document.getElementById('slug').value,
    excerpt: document.getElementById('excerpt').value,
    category: document.getElementById('category').value,
    tags: document.getElementById('tags').value,
    status: document.getElementById('status').value,
    body: document.getElementById('body').value
  });
  clearArticleForm();
  await refreshArticleList();
  alert('保存しました');
}

async function removeArticle(id) {
  if (!confirm('削除しますか？')) return;
  await deleteArticle(id);
  await refreshArticleList();
}

async function initAdminRankings() {
  await initAdminShell('rankings');
  const [rankings, searches, clicks] = await Promise.all([listRankings(100), listEvents('searchEvents', 100), listEvents('affiliateClicks', 100)]);
  document.getElementById('rankings-admin').innerHTML = renderRankingTable(rankings);
  document.getElementById('search-events-admin').innerHTML = renderEventTable(searches, ['keyword','category','source','createdAt']);
  document.getElementById('click-events-admin').innerHTML = renderEventTable(clicks, ['provider','keyword','url','createdAt']);
}

function renderRankingTable(rows) {
  return rows.length ? `<div class="table-wrap"><table><thead><tr><th>#</th><th>Keyword</th><th>Category</th><th>Search</th><th>Click</th><th>Score</th></tr></thead><tbody>${rows.map((r, i) => `<tr><td>${i + 1}</td><td>${escapeHtml(r.keyword)}</td><td>${escapeHtml(r.category || '')}</td><td>${Number(r.count || 0)}</td><td>${Number(r.clickCount || 0)}</td><td>${Number(r.score || 0)}</td></tr>`).join('')}</tbody></table></div>` : '<div class="notice">データがありません。</div>';
}

function renderEventTable(rows, keys) {
  return rows.length ? `<div class="table-wrap"><table><thead><tr>${keys.map(k => `<th>${escapeHtml(k)}</th>`).join('')}</tr></thead><tbody>${rows.map(row => `<tr>${keys.map(k => `<td>${escapeHtml(row[k] || '')}</td>`).join('')}</tr>`).join('')}</tbody></table></div>` : '<div class="notice">データがありません。</div>';
}

async function exportDataFile() {
  const data = await exportAllData();
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = `allergy-checker-export-${new Date().toISOString().slice(0,10)}.json`;
  a.click();
  URL.revokeObjectURL(a.href);
}

function importDataFile(input) {
  const file = input.files && input.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = async e => {
    try {
      const data = JSON.parse(e.target.result);
      await importAllData(data);
      alert('インポートしました');
      location.reload();
    } catch (err) {
      alert('インポート失敗: ' + err.message);
    }
  };
  reader.readAsText(file);
}


// Overrides with fast allergen check settings.
async function initAdminConfig() {
  await initAdminShell('config');
  const cfg = await getConfig();
  document.getElementById('siteName').value = cfg.siteName || '';
  document.getElementById('siteUrl').value = cfg.siteUrl || '';
  document.getElementById('contactEmail').value = cfg.contactEmail || '';
  document.getElementById('geminiApiKey').value = cfg.geminiApiKey || '';
  document.getElementById('geminiModel').value = cfg.geminiModel || 'gemini-2.0-flash';
  document.getElementById('requestMode').value = cfg.requestMode || 'mock';
  const fast = document.getElementById('fastAllergenCheckEnabled');
  if (fast) fast.checked = cfg.fastAllergenCheckEnabled !== false;
  const ocr = document.getElementById('ocrEngine');
  if (ocr) ocr.value = cfg.ocrEngine || 'gemini';
  const judge = document.getElementById('judgementEngine');
  if (judge) judge.value = cfg.judgementEngine || 'local';
  document.getElementById('safetyDisclaimer').value = cfg.safetyDisclaimer || DEFAULT_CONFIG.safetyDisclaimer;
  document.getElementById('affiliateDisclosure').value = cfg.affiliateDisclosure || DEFAULT_CONFIG.affiliateDisclosure;
}

async function saveAdminConfig() {
  const current = await getConfig();
  const fast = document.getElementById('fastAllergenCheckEnabled');
  const ocr = document.getElementById('ocrEngine');
  const judge = document.getElementById('judgementEngine');
  await saveConfig({
    ...current,
    siteName: document.getElementById('siteName').value,
    siteUrl: document.getElementById('siteUrl').value,
    contactEmail: document.getElementById('contactEmail').value,
    geminiApiKey: document.getElementById('geminiApiKey').value,
    geminiModel: document.getElementById('geminiModel').value,
    requestMode: document.getElementById('requestMode').value,
    fastAllergenCheckEnabled: fast ? fast.checked : true,
    ocrEngine: ocr ? ocr.value : 'gemini',
    judgementEngine: judge ? judge.value : 'local',
    safetyDisclaimer: document.getElementById('safetyDisclaimer').value,
    affiliateDisclosure: document.getElementById('affiliateDisclosure').value
  });
  alert('保存しました');
}
